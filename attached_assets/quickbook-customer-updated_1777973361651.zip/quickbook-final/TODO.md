# Fix @que/utils + env/DB issues

## Steps:
- [x] 1. @que/utils dep added & installed ✅
- [x] 2. `apps/api/.env` created with DATABASE_URL & JWT_SECRET ✅
- [x] 3. `pnpm --filter @que/api run db:migrate` — Generated Prisma Client ✅ (DB in sync)
- [x] 4. Restart dev server (Ctrl+C old ones, run `pnpm --filter @que/api run dev`)

**Status:** Module fixed, env ready, Prisma ready. Restart dev to connect to Postgres DB "queue_booking".
