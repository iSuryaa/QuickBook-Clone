// ============================================================
// Domain Types — shared across frontend and backend
// ============================================================

// --------------- Enums / literal unions ---------------

export type CategoryId =
  | "hospital"
  | "salon"
  | "hotel"
  | "gym"
  | "restaurant"
  | "entertainment"
  | "games";

export type BookingStatus =
  | "upcoming"
  | "completed"
  | "cancelled"
  | "in-queue";

export type AddressLabel = "home" | "work" | "other";

export type PriceLevel = 1 | 2 | 3 | 4;

export type UserRole = "customer" | "staff" | "admin";

// --------------- Core domain models ---------------

export interface Category {
  id: CategoryId;
  name: string;
  color: string;
  /** Whether a person-count picker is shown during booking */
  needsPersons: boolean;
}

export interface Service {
  id: string;
  name: string;
  /** Duration in minutes */
  duration: number;
  /** Price in INR paise (smallest unit) — display as ₹price/100 */
  price: number;
  photo?: string;
}

export interface StaffMember {
  id: string;
  name: string;
  role: string;
  rating: number;
}

export interface Business {
  id: string;
  name: string;
  category: CategoryId;
  rating: number;
  reviewCount: number;
  /** Distance in km from user */
  distanceKm: number;
  priceLevel: PriceLevel;
  openNow: boolean;
  imageUrl: string;
  address: string;
  phone: string;
  website: string;
  description: string;
  /** Estimated wait time in minutes */
  waitTimeMinutes: number;
  queueCount: number;
  services: Service[];
  staff: StaffMember[];
  photos?: string[];
  amenities?: string[];
  openHours?: WeeklyHours;
}

export type Weekday = "Mon" | "Tue" | "Wed" | "Thu" | "Fri" | "Sat" | "Sun";
export type WeeklyHours = Record<Weekday, string>;

export interface Movie {
  id: string;
  title: string;
  posterUrl: string;
  rating: number;
  /** Duration in minutes */
  durationMinutes: number;
  genre: string;
  language: string;
  description: string;
}

export interface Review {
  id: string;
  businessId: string;
  author: string;
  rating: number;
  /** Display-friendly date string, e.g. "2 days ago" */
  date: string;
  text: string;
}

export interface Booking {
  id: string;
  businessId: string;
  serviceId: string;
  staffId: string | null;
  movieId?: string;
  /** ISO date string, e.g. "2025-06-15" */
  date: string;
  /** Time string, e.g. "10:30 AM" */
  time: string;
  /** Unix timestamp of appointment start */
  scheduledAt?: number;
  persons: number;
  seats?: string[];
  status: BookingStatus;
  isWalkIn: boolean;
  queuePosition?: number;
  initialQueuePosition?: number;
  /** Booking convenience fee in paise */
  bookingFee?: number;
  /** Short reference token, e.g. "QB-1234" */
  token?: string;
  /** Unix timestamp of when booking was created */
  createdAt: number;
  customerName?: string;
  customerAge?: number;
}

export interface SavedCard {
  id: string;
  brand: string;
  /** Masked card number for display */
  number: string;
  last4: string;
  cardholderName: string;
  expiryMmYy: string;
}

export interface UserProfile {
  name: string;
  email: string;
  phone: string;
}

export interface AuthState {
  loggedIn: boolean;
  phone: string;
}

export interface Address {
  id: string;
  label: AddressLabel;
  /** Custom tag for "other" label */
  tag?: string;
  line1: string;
  line2?: string;
  city: string;
  pincode: string;
}

export interface Notification {
  id: string;
  title: string;
  body: string;
  time: string;
  read: boolean;
}

export interface Filters {
  minRating: number;
  /** Max distance in km */
  maxDistanceKm: number;
  openOnly: boolean;
  priceLevels: PriceLevel[];
}

// --------------- API shapes ---------------

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface ApiError {
  message: string;
  code?: string;
  statusCode: number;
}
