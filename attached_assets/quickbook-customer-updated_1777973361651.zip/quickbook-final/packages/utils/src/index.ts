import type { Booking, Filters, Business } from "@que/types";

// ============================================================
// Formatting
// ============================================================

/** Format a number as Indian Rupees, e.g. 1234 → "₹1,234" */
export function formatINR(amount: number): string {
  return `₹${amount.toLocaleString("en-IN")}`;
}

/** Format minutes to a human-readable duration, e.g. 90 → "1 hr 30 min" */
export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} min`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m === 0 ? `${h} hr` : `${h} hr ${m} min`;
}

/** Format a price level as rupee signs, e.g. 2 → "₹₹" */
export function formatPriceLevel(level: number): string {
  return "₹".repeat(level);
}

// ============================================================
// Booking helpers
// ============================================================

const BOOKING_CANCEL_WINDOW_MS = 60 * 60 * 1000; // 1 hour

/** Returns the scheduled timestamp for a booking, if any. */
export function getScheduledAt(booking: Booking): number | null {
  return typeof booking.scheduledAt === "number" ? booking.scheduledAt : null;
}

/** Whether a booking can still be cancelled (more than 1 hour before start). */
export function canCancelBooking(booking: Booking): boolean {
  const at = getScheduledAt(booking);
  if (at == null) return true;
  return at - Date.now() > BOOKING_CANCEL_WINDOW_MS;
}

/** Generate a short booking reference token, e.g. "QB-4821" */
export function generateBookingToken(): string {
  const n = Math.floor(1000 + Math.random() * 9000);
  return `QB-${n}`;
}

// ============================================================
// Business / search helpers
// ============================================================

/** Apply filter criteria to a list of businesses. */
export function applyFilters(
  businesses: Business[],
  filters: Filters,
  query: string,
): Business[] {
  const q = query.toLowerCase().trim();

  return businesses.filter((b) => {
    if (q && !b.name.toLowerCase().includes(q) && !b.description.toLowerCase().includes(q)) {
      return false;
    }
    if (b.rating < filters.minRating) return false;
    if (b.distanceKm > filters.maxDistanceKm) return false;
    if (filters.openOnly && !b.openNow) return false;
    if (!filters.priceLevels.includes(b.priceLevel)) return false;
    return true;
  });
}

// ============================================================
// Date / time helpers
// ============================================================

/** Return the current weekday key ("Mon" | "Tue" | ...) */
export function todayWeekdayKey(): "Sun" | "Mon" | "Tue" | "Wed" | "Thu" | "Fri" | "Sat" {
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"] as const;
  return days[new Date().getDay()];
}

/** Generate an array of available time slots for a given day. */
export function generateTimeSlots(
  startHour = 9,
  endHour = 21,
  intervalMinutes = 30,
): string[] {
  const slots: string[] = [];
  let h = startHour;
  let m = 0;
  while (h < endHour || (h === endHour && m === 0)) {
    const hour12 = h % 12 === 0 ? 12 : h % 12;
    const ampm = h < 12 ? "AM" : "PM";
    const mm = m === 0 ? "00" : `${m}`;
    slots.push(`${hour12}:${mm} ${ampm}`);
    m += intervalMinutes;
    if (m >= 60) { m = 0; h++; }
  }
  return slots;
}

// ============================================================
// Misc
// ============================================================

/** Generate a short random ID. */
export function generateId(): string {
  return Math.random().toString(36).slice(2, 10);
}

/** Deep-clone a serialisable value. */
export function deepClone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}
