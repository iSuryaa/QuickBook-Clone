import { z } from "zod";

export const createBookingSchema = z.object({
  businessId: z.string().min(1),
  serviceId: z.string().min(1),
  staffId: z.string().nullable(),
  movieId: z.string().optional(),
  date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format"),
  time: z.string().min(1, "Time is required"),
  persons: z.number().int().min(1).max(20),
  seats: z.array(z.string()).optional(),
  isWalkIn: z.boolean().default(false),
  customerName: z.string().optional(),
  customerAge: z.number().int().min(0).max(150).optional(),
});

export const updateBookingStatusSchema = z.object({
  status: z.enum(["upcoming", "completed", "cancelled", "in-queue"]),
});

export const bookingFiltersSchema = z.object({
  status: z
    .enum(["upcoming", "completed", "cancelled", "in-queue"])
    .optional(),
  businessId: z.string().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export type CreateBookingInput = z.infer<typeof createBookingSchema>;
export type UpdateBookingStatusInput = z.infer<typeof updateBookingStatusSchema>;
export type BookingFilters = z.infer<typeof bookingFiltersSchema>;
