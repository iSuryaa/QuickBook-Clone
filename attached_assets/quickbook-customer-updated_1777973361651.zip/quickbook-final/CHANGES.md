# Changes & Implemented Features

## New Files Added

### `features/businesses/BusinessDetailSheet.tsx`
Full business detail bottom sheet with:
- Hero image with gradient overlay, open/closed badge, queue count badge
- Favourite (heart) toggle wired to `useToggleFavorite`
- Quick stats row: rating, distance, wait time, price level
- 3 tabs: **Overview** (about, contact, open hours, amenities), **Services** (selectable + staff picker), **Reviews** (paginated)
- Sticky "Book" CTA that pre-fills `BookingFlowSheet` with selected service/staff
- Shows "Currently Closed" disabled state when `!business.openNow`

### `features/bookings/BookingFlowSheet.tsx`
Complete 3-step booking wizard:
- **Step 1 — Date & Time**: horizontal scrollable date pills (14 days), service picker (if not pre-selected), 3-column time-slot grid
- **Step 2 — Persons**: large +/− counter, schedule/staff/service summary cards
- **Step 3 — Confirm**: full price breakdown (service + ₹15 booking fee + 18% GST), cancellation policy notice
- **Step 4 — Success**: animated checkmark, token display, CTA to view bookings
- Calls `useCreateBooking` → invalidates bookings cache → navigates to bookings tab

### `features/bookings/QueueTrackerSheet.tsx`
Live queue tracker with 30s auto-polling:
- Big colour-coded position counter (green=1, amber=≤3, indigo=rest)
- Token display, address, date/time, persons info card
- 4-step animated progress timeline (Booking confirmed → In queue → Your turn → Serving)
- Hourly-wait bar chart from queue data
- Cancel booking with confirmation guard
- "Updated at HH:MM · refreshes every 30s" footer note

### `features/bookings/BookingDetailSheet.tsx`
Full booking detail overlay:
- Status chip (Upcoming / In Queue / Completed / Cancelled) with colour coding
- QR code placeholder with token in monospace font
- Details rows: location, date, time, persons, queue position, total paid
- Cancel with 1-click confirm guard
- "Track queue →" CTA for `in-queue` bookings

### `features/profile/NotificationsPanel.tsx`
Notifications bottom sheet:
- Unread count badge + "Mark all read" button
- Per-notification icon derived from title keywords (Calendar, Clock, Gift, Star, Bell)
- Per-notification accent colour (red=cancel, green=confirm, amber=queue, purple=offer)
- Left-border highlight + dot for unread items
- Individual delete (trash icon) calling `useDeleteNotification`
- Empty state illustration

### `features/profile/EditProfileSheet.tsx`
Profile editor:
- Avatar initial preview that updates live as name is typed
- Name (editable), Phone (disabled, read-only), Email (optional)
- Calls `useUpdateProfile` → shows toast on success/error

### `features/profile/AddressesSheet.tsx`
Address manager:
- List of saved addresses with Home/Work/Other icons
- Inline "Add address" form with label picker pills (Home/Work/Other)
- Individual delete with toast feedback
- Empty-state CTA

### `features/profile/FavouritesSheet.tsx`
Favourites manager:
- Card list with business image, name, rating, distance, open status
- "View & Book" → closes sheet → opens BusinessDetailSheet
- "Remove" → calls `useToggleFavorite` → optimistically removes

## Updated Files

### `features/shared/AppShell.tsx`
- Unified modal state machine (`ModalType` discriminated union)
- All `onClick={() => {}}` placeholders replaced with real handlers
- Bell icon → opens `NotificationsPanel` (requires login)
- Business card click → opens `BusinessDetailSheet`
- Business detail "Book" → opens `BookingFlowSheet`
- BookingFlowSheet success → navigates to Bookings tab
- Queue track → opens `QueueTrackerSheet`
- Profile menu items → open respective sheets
- `upcomingCount` badge on Bookings tab from live query

### `features/shared/tabs/HomeTab.tsx`
- Search input now navigates to Explore tab with the query prefilled
- Bell button wired to `onOpenNotifications` (with login guard)
- Category tiles wired to `onGoExplore(categoryId)`
- "See all" / "All categories" wired
- Business card click → `onViewBusiness`
- Favourite toggle wired

### `features/shared/tabs/ExploreTab.tsx`
- Active filter count badge on filter button
- Category pills now drive API query via `category` param
- Business card click → `onViewBusiness`
- Respects `initialCategory` from HomeTab navigation

### `features/shared/tabs/BookingsTab.tsx`
- `onViewDetails` now opens `BookingDetailSheet` (was `() => {}`)
- `onViewQueue` now opens `QueueTrackerSheet` (was `() => {}`)
- `businessId` resolved to human name via `useBusinesses` lookup
- `serviceId` passed as `serviceName` (API can extend to name lookup)
- Status filter tabs: All / Upcoming / In Queue / Completed / Cancelled

### `features/shared/tabs/ProfileTab.tsx`
- All menu items wired (Edit Profile, Notifications, Addresses, Payment, Favourites)
- Unread notification count badge on Bell menu item
- Sign in empty state for logged-out users
- Sign out calls `logout()` from auth context

### `features/auth/LoginScreen.tsx`
- Converted from full-screen page to overlay bottom sheet
- Matches existing design system (same rounding, indigo buttons, slate inputs)
- Backdrop dismiss safe

### `features/profile/use-profile.ts`
- Notifications refetch every 60s for live badge updates
- `useUpdateProfile` now invalidates profile cache
- Favourites staleTime set to 1 minute

### `features/bookings/use-bookings.ts`
- `useBookings` staleTime: 30s (faster fresh data for My Bookings)
- `useQueuePosition` staleTime: 0 (always fresh for live tracking)

### `packages/utils/src/index.ts`
- `formatPriceLevel` now returns `₹₹` instead of `$$`

### `apps/customer-app/src/app/globals.css`
- Added `.pb-safe` utility for notch-safe bottom padding
- Added `animate-in`, `fade-in`, `slide-in-from-bottom-2` for Toast animations
- Added `.animate-ping` for live-indicator dot
