import { Router } from "express";
import authRoutes from "./modules/auth/auth.routes.js";
import userRoutes from "./modules/users/users.routes.js";
import businessRoutes from "./modules/businesses/businesses.routes.js";
import bookingRoutes from "./modules/bookings/bookings.routes.js";
import staffRoutes from "./modules/staff/staff.routes.js";
import paymentRoutes from "./modules/payments/payments.routes.js";

export const router = Router();

// Health check
router.get("/healthz", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Feature modules
router.use("/auth", authRoutes);
router.use("/users", userRoutes);
router.use("/businesses", businessRoutes);
router.use("/bookings", bookingRoutes);
router.use("/staff", staffRoutes);
router.use("/payments", paymentRoutes);
