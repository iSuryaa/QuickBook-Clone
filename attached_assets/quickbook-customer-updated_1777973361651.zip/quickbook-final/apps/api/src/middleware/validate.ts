import type { RequestHandler } from "express";
import type { ZodSchema } from "zod";

/** Validate req.body against a Zod schema and replace it with the parsed value. */
export function validateBody<T>(schema: ZodSchema<T>): RequestHandler {
  return (req, _res, next) => {
    const result = schema.safeParse(req.body);
    if (!result.success) return next(result.error);
    req.body = result.data;
    next();
  };
}

/** Validate req.query against a Zod schema. */
export function validateQuery<T>(schema: ZodSchema<T>): RequestHandler {
  return (req, _res, next) => {
    const result = schema.safeParse(req.query);
    if (!result.success) return next(result.error);
    (req as unknown as Record<string, unknown>).validatedQuery = result.data;
    next();
  };
}
