import type { RequestHandler } from "express";
import { verifyToken, type JwtPayload } from "../lib/jwt.js";
import { UnauthorizedError } from "../lib/errors.js";

// Extend Express request with authenticated user
declare global {
  namespace Express {
    interface Request {
      user?: JwtPayload;
    }
  }
}

/** Middleware that enforces a valid JWT in the Authorization header. */
export const authenticate: RequestHandler = (req, _res, next) => {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return next(new UnauthorizedError("Missing or malformed Authorization header"));
  }

  const token = header.slice(7);
  try {
    req.user = verifyToken(token);
    next();
  } catch {
    next(new UnauthorizedError("Invalid or expired token"));
  }
};

/** Middleware that restricts access to specific roles. */
export function requireRole(...roles: string[]): RequestHandler {
  return (req, _res, next) => {
    if (!req.user) {
      return next(new UnauthorizedError());
    }
    if (!roles.includes(req.user.role)) {
      return next(new UnauthorizedError("Insufficient permissions"));
    }
    next();
  };
}
