import type { RequestHandler } from "express";
import { bookingsService } from "./bookings.service.js";
import { createBookingSchema } from "@que/shared/schemas";
import { validateBody } from "../../middleware/validate.js";
import { UnauthorizedError } from "../../lib/errors.js";

function uid(req: Parameters<RequestHandler>[0]): string {
  if (!req.user) throw new UnauthorizedError();
  return req.user.userId;
}

export const bookingsController = {
  list: (async (req, res, next) => {
    try {
      const status = typeof req.query.status === "string" ? req.query.status : undefined;
      res.json(await bookingsService.listForUser(uid(req), status));
    } catch (e) { next(e); }
  }) satisfies RequestHandler,

  getById: (async (req, res, next) => {
    try {
      res.json(await bookingsService.getById(req.params.id, uid(req)));
    } catch (e) { next(e); }
  }) satisfies RequestHandler,

  create: [
    validateBody(createBookingSchema),
    (async (req, res, next) => {
      try {
        const booking = await bookingsService.create(uid(req), req.body);
        res.status(201).json(booking);
      } catch (e) { next(e); }
    }) satisfies RequestHandler,
  ],

  cancel: (async (req, res, next) => {
    try {
      res.json(await bookingsService.cancel(req.params.id, uid(req)));
    } catch (e) { next(e); }
  }) satisfies RequestHandler,

  getQueuePosition: (async (req, res, next) => {
    try {
      res.json(await bookingsService.getQueuePosition(req.params.id, uid(req)));
    } catch (e) { next(e); }
  }) satisfies RequestHandler,
};
