import { bookingsRepository, type CreateBookingData } from "./bookings.repository.js";
import { prisma } from "../../lib/prisma.js";
import { BadRequestError, ForbiddenError, NotFoundError } from "../../lib/errors.js";

const BOOKING_FEE_PAISE = 4900; // ₹49

export const bookingsService = {
  listForUser: (userId: string, status?: string) =>
    bookingsRepository.findByUser(userId, status),

  async getById(bookingId: string, userId: string) {
    const booking = await bookingsRepository.findByIdAndUser(bookingId, userId);
    if (!booking) throw new NotFoundError("Booking");
    return booking;
  },

  async create(userId: string, input: Omit<CreateBookingData, "userId" | "bookingFeeInPaise">) {
    // Verify the service belongs to the business
    const service = await prisma.service.findFirst({
      where: { id: input.serviceId, businessId: input.businessId },
    });
    if (!service) throw new BadRequestError("Service does not belong to this business");

    // Verify staff if provided
    if (input.staffId) {
      const staff = await prisma.staff.findFirst({
        where: { id: input.staffId, businessId: input.businessId },
      });
      if (!staff) throw new BadRequestError("Staff member not found at this business");
    }

    const booking = await bookingsRepository.create({
      ...input,
      userId,
      bookingFeeInPaise: BOOKING_FEE_PAISE,
      scheduledAt: input.scheduledAt,
    });

    // Create a notification for the user
    await prisma.notification.create({
      data: {
        userId,
        title: input.isWalkIn ? "You're in the queue!" : "Booking confirmed!",
        body: `${booking.business.name} — ${input.isWalkIn ? `Queue position #${booking.queuePosition ?? 1}` : `${input.date} at ${input.time}`}`,
      },
    });

    return booking;
  },

  async cancel(bookingId: string, userId: string) {
    const booking = await bookingsRepository.findByIdAndUser(bookingId, userId);
    if (!booking) throw new NotFoundError("Booking");
    if (booking.status === "CANCELLED") {
      throw new BadRequestError("Booking is already cancelled");
    }
    if (booking.status === "COMPLETED") {
      throw new BadRequestError("Completed bookings cannot be cancelled");
    }

    // Enforce 1-hour cancellation window for scheduled bookings
    if (booking.scheduledAt) {
      const msUntil = booking.scheduledAt.getTime() - Date.now();
      if (msUntil < 60 * 60 * 1000) {
        throw new ForbiddenError("Cannot cancel within 1 hour of the appointment");
      }
    }

    return bookingsRepository.updateStatus(bookingId, "CANCELLED");
  },

  async getQueuePosition(bookingId: string, userId: string) {
    const booking = await bookingsRepository.findByIdAndUser(bookingId, userId);
    if (!booking) throw new NotFoundError("Booking");
    const position = await bookingsRepository.findQueuePosition(booking.businessId, bookingId);
    return { position, booking };
  },
};
