import { prisma } from "../../lib/prisma.js";
import type { Prisma } from "@prisma/client";
import { generateBookingToken } from "@que/utils";

export interface CreateBookingData {
  userId: string;
  businessId: string;
  serviceId: string;
  staffId?: string | null;
  movieId?: string;
  date: string;
  time: string;
  scheduledAt?: Date;
  persons: number;
  seats?: string[];
  isWalkIn: boolean;
  bookingFeeInPaise?: number;
  customerName?: string;
  customerAge?: number;
}

const bookingInclude = {
  business: { select: { id: true, name: true, imageUrl: true, address: true, phone: true } },
  service: { select: { id: true, name: true, durationMins: true, priceInPaise: true } },
  staff: { select: { id: true, name: true, role: true } },
  payment: true,
} satisfies Prisma.BookingInclude;

export const bookingsRepository = {
  findByUser: (userId: string, status?: string) =>
    prisma.booking.findMany({
      where: { userId, ...(status ? { status: status as Prisma.EnumBookingStatusFilter } : {}) },
      include: bookingInclude,
      orderBy: { createdAt: "desc" },
    }),

  findById: (id: string) =>
    prisma.booking.findUnique({ where: { id }, include: bookingInclude }),

  findByIdAndUser: (id: string, userId: string) =>
    prisma.booking.findFirst({ where: { id, userId }, include: bookingInclude }),

  create: (data: CreateBookingData) =>
    prisma.booking.create({
      data: {
        ...data,
        seats: data.seats ?? [],
        token: generateBookingToken(),
      },
      include: bookingInclude,
    }),

  updateStatus: (id: string, status: string) =>
    prisma.booking.update({
      where: { id },
      data: { status: status as Prisma.EnumBookingStatusFilter },
      include: bookingInclude,
    }),

  findQueuePosition: async (businessId: string, bookingId: string) => {
    const queue = await prisma.booking.findMany({
      where: { businessId, status: "IN_QUEUE" },
      orderBy: { createdAt: "asc" },
      select: { id: true },
    });
    const pos = queue.findIndex((b) => b.id === bookingId);
    return pos === -1 ? null : pos + 1;
  },
};
