import { Router } from "express";
import { bookingsController } from "./bookings.controller.js";
import { authenticate } from "../../middleware/authenticate.js";

const router = Router();

router.use(authenticate);

router.get("/", bookingsController.list);
router.post("/", ...bookingsController.create);
router.get("/:id", bookingsController.getById);
router.post("/:id/cancel", bookingsController.cancel);
router.get("/:id/queue", bookingsController.getQueuePosition);

export default router;
