import { prisma } from "../../lib/prisma.js";

export const authRepository = {
  findUserByPhone: (phone: string) =>
    prisma.user.findUnique({ where: { phone } }),

  createUser: (data: { phone: string; name: string; email?: string }) =>
    prisma.user.create({ data }),

  createOtp: (phone: string, code: string, expiresAt: Date) =>
    prisma.otpCode.create({ data: { phone, code, expiresAt } }),

  findValidOtp: (phone: string, code: string) =>
    prisma.otpCode.findFirst({
      where: {
        phone,
        code,
        used: false,
        expiresAt: { gt: new Date() },
      },
      orderBy: { createdAt: "desc" },
    }),

  markOtpUsed: (id: string) =>
    prisma.otpCode.update({ where: { id }, data: { used: true } }),
};
