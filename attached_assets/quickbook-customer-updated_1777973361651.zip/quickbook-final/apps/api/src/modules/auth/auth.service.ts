import { authRepository } from "./auth.repository.js";
import { signToken } from "../../lib/jwt.js";
import { BadRequestError, NotFoundError } from "../../lib/errors.js";
import { logger } from "../../lib/logger.js";

const OTP_EXPIRY_MS = 10 * 60 * 1000; // 10 minutes

export const authService = {
  async sendOtp(phone: string): Promise<void> {
    // In production, integrate an SMS gateway here.
    // For now, we generate and log the OTP.
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + OTP_EXPIRY_MS);

    await authRepository.createOtp(phone, code, expiresAt);

    // Log in dev, send via SMS in prod
    logger.info({ phone, code }, "OTP generated");
  },

  async verifyOtp(
    phone: string,
    code: string,
  ): Promise<{ token: string; isNewUser: boolean }> {
    const otp = await authRepository.findValidOtp(phone, code);
    if (!otp) {
      throw new BadRequestError("Invalid or expired OTP", "INVALID_OTP");
    }

    await authRepository.markOtpUsed(otp.id);

    const existingUser = await authRepository.findUserByPhone(phone);
    return {
      token: existingUser ? signToken({ userId: existingUser.id, role: existingUser.role }) : "",
      isNewUser: !existingUser,
    };
  },

  async completeSignup(phone: string, name: string, email?: string) {
    const existing = await authRepository.findUserByPhone(phone);
    if (existing) {
      throw new BadRequestError("User already exists", "USER_EXISTS");
    }

    const user = await authRepository.createUser({ phone, name, email });
    const token = signToken({ userId: user.id, role: user.role });
    return { token, user };
  },

  async loginByPhone(phone: string) {
    const user = await authRepository.findUserByPhone(phone);
    if (!user) {
      throw new NotFoundError("User");
    }
    const token = signToken({ userId: user.id, role: user.role });
    return { token, user };
  },
};
