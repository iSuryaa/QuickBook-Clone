import type { RequestHandler } from "express";
import { authService } from "./auth.service.js";

export const authController = {
  sendOtp: (async (req, res, next) => {
    try {
      await authService.sendOtp(req.body.phone);
      res.json({ message: "OTP sent" });
    } catch (err) {
      next(err);
    }
  }) satisfies RequestHandler,

  verifyOtp: (async (req, res, next) => {
    try {
      const result = await authService.verifyOtp(req.body.phone, req.body.otp);
      res.json(result);
    } catch (err) {
      next(err);
    }
  }) satisfies RequestHandler,

  completeSignup: (async (req, res, next) => {
    try {
      const result = await authService.completeSignup(
        req.body.phone,
        req.body.name,
        req.body.email,
      );
      res.status(201).json(result);
    } catch (err) {
      next(err);
    }
  }) satisfies RequestHandler,

  me: (async (req, res) => {
    res.json({ user: req.user });
  }) satisfies RequestHandler,
};
