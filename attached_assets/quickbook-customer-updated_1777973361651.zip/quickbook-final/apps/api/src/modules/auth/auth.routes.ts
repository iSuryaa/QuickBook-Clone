import { Router } from "express";
import { authController } from "./auth.controller.js";
import { authenticate } from "../../middleware/authenticate.js";
import { validateBody } from "../../middleware/validate.js";
import {
  sendOtpSchema,
  verifyOtpSchema,
  signupSchema,
} from "@que/shared/schemas";

const router = Router();

// POST /api/auth/otp/send
router.post("/otp/send", validateBody(sendOtpSchema), authController.sendOtp);

// POST /api/auth/otp/verify
router.post("/otp/verify", validateBody(verifyOtpSchema), authController.verifyOtp);

// POST /api/auth/signup
router.post("/signup", validateBody(signupSchema), authController.completeSignup);

// GET /api/auth/me  — requires auth
router.get("/me", authenticate, authController.me);

export default router;
