import { prisma } from "../../lib/prisma.js";
import type { Prisma } from "@prisma/client";

export interface BusinessFilters {
  category?: string;
  search?: string;
  openOnly?: boolean;
  minRating?: number;
  maxPriceLevel?: number;
  page?: number;
  pageSize?: number;
}

const businessSelect = {
  id: true,
  name: true,
  category: true,
  rating: true,
  reviewCount: true,
  distanceKm: true,
  priceLevel: true,
  openNow: true,
  imageUrl: true,
  address: true,
  phone: true,
  website: true,
  description: true,
  waitTimeMinutes: true,
  queueCount: true,
  photos: true,
  amenities: true,
} satisfies Prisma.BusinessSelect;

export const businessesRepository = {
  findMany: async (filters: BusinessFilters) => {
    const { category, search, openOnly, minRating, maxPriceLevel, page = 1, pageSize = 20 } = filters;

    const where: Prisma.BusinessWhereInput = {};
    if (category) where.category = category as Prisma.EnumCategoryIdFilter;
    if (openOnly) where.openNow = true;
    if (minRating) where.rating = { gte: minRating };
    if (maxPriceLevel) where.priceLevel = { lte: maxPriceLevel };
    if (search) {
      where.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
        { address: { contains: search, mode: "insensitive" } },
      ];
    }

    const [data, total] = await Promise.all([
      prisma.business.findMany({
        where,
        select: businessSelect,
        skip: (page - 1) * pageSize,
        take: pageSize,
        orderBy: { rating: "desc" },
      }),
      prisma.business.count({ where }),
    ]);

    return { data, total, page, pageSize };
  },

  findById: (id: string) =>
    prisma.business.findUnique({
      where: { id },
      include: {
        services: true,
        staff: true,
        openHours: true,
      },
    }),

  findReviews: (businessId: string, page = 1, pageSize = 20) =>
    prisma.review.findMany({
      where: { businessId },
      include: { user: { select: { name: true } } },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),

  createReview: (data: {
    userId: string;
    businessId: string;
    rating: number;
    text: string;
  }) =>
    prisma.$transaction(async (tx) => {
      const review = await tx.review.create({ data });

      // Recompute average rating
      const agg = await tx.review.aggregate({
        where: { businessId: data.businessId },
        _avg: { rating: true },
        _count: true,
      });
      await tx.business.update({
        where: { id: data.businessId },
        data: {
          rating: agg._avg.rating ?? 0,
          reviewCount: agg._count,
        },
      });

      return review;
    }),
};
