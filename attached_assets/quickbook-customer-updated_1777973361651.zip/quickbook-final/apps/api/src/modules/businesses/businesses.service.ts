import { businessesRepository, type BusinessFilters } from "./businesses.repository.js";
import { NotFoundError } from "../../lib/errors.js";

export const businessesService = {
  list: (filters: BusinessFilters) => businessesRepository.findMany(filters),

  async getById(id: string) {
    const business = await businessesRepository.findById(id);
    if (!business) throw new NotFoundError("Business");
    return business;
  },

  getReviews: (businessId: string, page?: number, pageSize?: number) =>
    businessesRepository.findReviews(businessId, page, pageSize),

  async addReview(userId: string, businessId: string, rating: number, text: string) {
    // Verify business exists before creating review
    const business = await businessesRepository.findById(businessId);
    if (!business) throw new NotFoundError("Business");

    return businessesRepository.createReview({ userId, businessId, rating, text });
  },
};
