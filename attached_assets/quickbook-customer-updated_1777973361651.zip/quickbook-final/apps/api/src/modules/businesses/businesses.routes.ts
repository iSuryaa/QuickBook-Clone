import { Router } from "express";
import { businessesController } from "./businesses.controller.js";
import { authenticate } from "../../middleware/authenticate.js";

const router = Router();

// Public routes
router.get("/", businessesController.list);
router.get("/:id", businessesController.getById);
router.get("/:id/reviews", businessesController.getReviews);

// Authenticated routes
router.post("/:id/reviews", authenticate, businessesController.addReview);

export default router;
