import type { RequestHandler } from "express";
import { businessesService } from "./businesses.service.js";
import { z } from "zod";

const listQuerySchema = z.object({
  category: z.string().optional(),
  search: z.string().optional(),
  openOnly: z.coerce.boolean().optional(),
  minRating: z.coerce.number().optional(),
  maxPriceLevel: z.coerce.number().int().min(1).max(4).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

const reviewBodySchema = z.object({
  rating: z.number().int().min(1).max(5),
  text: z.string().min(1).max(2000),
});

export const businessesController = {
  list: (async (req, res, next) => {
    try {
      const filters = listQuerySchema.parse(req.query);
      res.json(await businessesService.list(filters));
    } catch (e) { next(e); }
  }) satisfies RequestHandler,

  getById: (async (req, res, next) => {
    try {
      res.json(await businessesService.getById(req.params.id));
    } catch (e) { next(e); }
  }) satisfies RequestHandler,

  getReviews: (async (req, res, next) => {
    try {
      const page = Number(req.query.page) || 1;
      const pageSize = Number(req.query.pageSize) || 20;
      res.json(await businessesService.getReviews(req.params.id, page, pageSize));
    } catch (e) { next(e); }
  }) satisfies RequestHandler,

  addReview: (async (req, res, next) => {
    try {
      const { rating, text } = reviewBodySchema.parse(req.body);
      const review = await businessesService.addReview(
        req.user!.userId,
        req.params.id,
        rating,
        text,
      );
      res.status(201).json(review);
    } catch (e) { next(e); }
  }) satisfies RequestHandler,
};
