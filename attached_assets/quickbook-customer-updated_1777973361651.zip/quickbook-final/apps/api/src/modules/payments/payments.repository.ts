import { prisma } from "../../lib/prisma.js";

export const paymentsRepository = {
  findByBooking: (bookingId: string) =>
    prisma.payment.findUnique({ where: { bookingId } }),

  create: (data: {
    bookingId: string;
    amountInPaise: number;
    method: string;
  }) =>
    prisma.payment.create({
      data: { ...data, status: "PENDING" },
    }),

  markPaid: (bookingId: string, transactionId: string) =>
    prisma.payment.update({
      where: { bookingId },
      data: { status: "PAID", transactionId },
    }),

  markFailed: (bookingId: string) =>
    prisma.payment.update({
      where: { bookingId },
      data: { status: "FAILED" },
    }),
};
