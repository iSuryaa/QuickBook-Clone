import { paymentsRepository } from "./payments.repository.js";
import { bookingsRepository } from "../bookings/bookings.repository.js";
import { BadRequestError, ForbiddenError, NotFoundError } from "../../lib/errors.js";
import { generateId } from "@que/utils";

export const paymentsService = {
  async initiatePayment(bookingId: string, userId: string, method: string) {
    const booking = await bookingsRepository.findByIdAndUser(bookingId, userId);
    if (!booking) throw new NotFoundError("Booking");

    const existing = await paymentsRepository.findByBooking(bookingId);
    if (existing?.status === "PAID") throw new BadRequestError("Booking is already paid");

    // Get total amount: service price + booking fee
    const amount = booking.service.priceInPaise + (booking.bookingFeeInPaise ?? 0);

    const payment = await paymentsRepository.create({ bookingId, amountInPaise: amount, method });
    return payment;
  },

  async confirmPayment(bookingId: string, userId: string) {
    const booking = await bookingsRepository.findByIdAndUser(bookingId, userId);
    if (!booking) throw new NotFoundError("Booking");

    const payment = await paymentsRepository.findByBooking(bookingId);
    if (!payment) throw new NotFoundError("Payment");
    if (payment.status === "PAID") throw new BadRequestError("Already paid");

    // In production, verify with payment gateway here
    const transactionId = `TXN_${generateId().toUpperCase()}`;
    const confirmed = await paymentsRepository.markPaid(bookingId, transactionId);

    // Move booking to UPCOMING status after payment
    await bookingsRepository.updateStatus(bookingId, "UPCOMING");

    return confirmed;
  },

  async getPaymentForBooking(bookingId: string, userId: string) {
    const booking = await bookingsRepository.findByIdAndUser(bookingId, userId);
    if (!booking) throw new NotFoundError("Booking");
    const payment = await paymentsRepository.findByBooking(bookingId);
    if (!payment) throw new NotFoundError("Payment");
    return payment;
  },
};
