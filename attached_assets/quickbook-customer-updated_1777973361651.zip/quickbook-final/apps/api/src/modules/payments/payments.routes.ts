import { Router } from "express";
import type { RequestHandler } from "express";
import { paymentsService } from "./payments.service.js";
import { authenticate } from "../../middleware/authenticate.js";

const router = Router();
router.use(authenticate);

const uid = (req: Parameters<RequestHandler>[0]) => req.user!.userId;

// POST /api/payments/initiate
router.post("/initiate", async (req, res, next) => {
  try {
    const { bookingId, method } = req.body as { bookingId: string; method: string };
    res.status(201).json(await paymentsService.initiatePayment(bookingId, uid(req), method));
  } catch (e) { next(e); }
});

// POST /api/payments/confirm
router.post("/confirm", async (req, res, next) => {
  try {
    const { bookingId } = req.body as { bookingId: string };
    res.json(await paymentsService.confirmPayment(bookingId, uid(req)));
  } catch (e) { next(e); }
});

// GET /api/payments/booking/:bookingId
router.get("/booking/:bookingId", async (req, res, next) => {
  try {
    res.json(await paymentsService.getPaymentForBooking(req.params.bookingId, uid(req)));
  } catch (e) { next(e); }
});

export default router;
