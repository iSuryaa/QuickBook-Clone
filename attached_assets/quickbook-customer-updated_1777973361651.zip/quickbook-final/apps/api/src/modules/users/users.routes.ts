import { Router } from "express";
import { usersController } from "./users.controller.js";
import { authenticate } from "../../middleware/authenticate.js";

const router = Router();

// All user routes require auth
router.use(authenticate);

// Profile
router.get("/me", usersController.getProfile);
router.patch("/me", usersController.updateProfile);

// Addresses
router.get("/me/addresses", usersController.getAddresses);
router.post("/me/addresses", usersController.addAddress);
router.patch("/me/addresses/:id", usersController.updateAddress);
router.delete("/me/addresses/:id", usersController.deleteAddress);

// Saved cards
router.get("/me/cards", usersController.getCards);
router.post("/me/cards", usersController.addCard);
router.delete("/me/cards/:id", usersController.deleteCard);

// Favorites
router.get("/me/favorites", usersController.getFavorites);
router.post("/me/favorites/:businessId", usersController.toggleFavorite);

// Notifications
router.get("/me/notifications", usersController.getNotifications);
router.patch("/me/notifications/:id/read", usersController.markNotificationRead);
router.post("/me/notifications/read-all", usersController.markAllNotificationsRead);
router.delete("/me/notifications/:id", usersController.deleteNotification);

export default router;
