import { usersRepository } from "./users.repository.js";
import { NotFoundError } from "../../lib/errors.js";

export const usersService = {
  async getProfile(userId: string) {
    const user = await usersRepository.findById(userId);
    if (!user) throw new NotFoundError("User");
    return user;
  },

  async updateProfile(userId: string, data: { name?: string; email?: string }) {
    const user = await usersRepository.findById(userId);
    if (!user) throw new NotFoundError("User");
    return usersRepository.update(userId, data);
  },

  // ── Addresses ────────────────────────────────────────────
  getAddresses: (userId: string) => usersRepository.findAddresses(userId),

  async addAddress(
    userId: string,
    data: {
      label: string;
      tag?: string;
      line1: string;
      line2?: string;
      city: string;
      pincode: string;
    },
  ) {
    return usersRepository.createAddress(userId, data);
  },

  async updateAddress(userId: string, addressId: string, data: Record<string, string>) {
    const existing = await usersRepository.findAddressById(addressId, userId);
    if (!existing) throw new NotFoundError("Address");
    return usersRepository.updateAddress(addressId, data);
  },

  async deleteAddress(userId: string, addressId: string) {
    const existing = await usersRepository.findAddressById(addressId, userId);
    if (!existing) throw new NotFoundError("Address");
    await usersRepository.deleteAddress(addressId);
  },

  // ── Saved cards ──────────────────────────────────────────
  getCards: (userId: string) => usersRepository.findCards(userId),

  addCard: (
    userId: string,
    data: {
      brand: string;
      maskedNumber: string;
      last4: string;
      cardholderName: string;
      expiryMmYy: string;
    },
  ) => usersRepository.createCard(userId, data),

  deleteCard: (userId: string, cardId: string) =>
    usersRepository.deleteCard(cardId, userId),

  // ── Favorites ────────────────────────────────────────────
  getFavorites: (userId: string) => usersRepository.findFavorites(userId),

  toggleFavorite: (userId: string, businessId: string) =>
    usersRepository.toggleFavorite(userId, businessId),

  // ── Notifications ────────────────────────────────────────
  getNotifications: (userId: string) => usersRepository.findNotifications(userId),

  markNotificationRead: (userId: string, notifId: string) =>
    usersRepository.markNotificationRead(notifId, userId),

  markAllNotificationsRead: (userId: string) => usersRepository.markAllRead(userId),

  deleteNotification: (userId: string, notifId: string) =>
    usersRepository.deleteNotification(notifId, userId),
};
