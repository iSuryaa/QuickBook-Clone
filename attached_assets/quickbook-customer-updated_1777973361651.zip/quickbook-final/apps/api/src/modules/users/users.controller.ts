import type { RequestHandler } from "express";
import { usersService } from "./users.service.js";
import { UnauthorizedError } from "../../lib/errors.js";

function userId(req: Parameters<RequestHandler>[0]): string {
  if (!req.user) throw new UnauthorizedError();
  return req.user.userId;
}

export const usersController = {
  getProfile: (async (req, res, next) => {
    try {
      res.json(await usersService.getProfile(userId(req)));
    } catch (e) { next(e); }
  }) satisfies RequestHandler,

  updateProfile: (async (req, res, next) => {
    try {
      res.json(await usersService.updateProfile(userId(req), req.body));
    } catch (e) { next(e); }
  }) satisfies RequestHandler,

  // Addresses
  getAddresses: (async (req, res, next) => {
    try { res.json(await usersService.getAddresses(userId(req))); } catch (e) { next(e); }
  }) satisfies RequestHandler,

  addAddress: (async (req, res, next) => {
    try { res.status(201).json(await usersService.addAddress(userId(req), req.body)); } catch (e) { next(e); }
  }) satisfies RequestHandler,

  updateAddress: (async (req, res, next) => {
    try { res.json(await usersService.updateAddress(userId(req), req.params.id, req.body)); } catch (e) { next(e); }
  }) satisfies RequestHandler,

  deleteAddress: (async (req, res, next) => {
    try { await usersService.deleteAddress(userId(req), req.params.id); res.status(204).send(); } catch (e) { next(e); }
  }) satisfies RequestHandler,

  // Cards
  getCards: (async (req, res, next) => {
    try { res.json(await usersService.getCards(userId(req))); } catch (e) { next(e); }
  }) satisfies RequestHandler,

  addCard: (async (req, res, next) => {
    try { res.status(201).json(await usersService.addCard(userId(req), req.body)); } catch (e) { next(e); }
  }) satisfies RequestHandler,

  deleteCard: (async (req, res, next) => {
    try { await usersService.deleteCard(userId(req), req.params.id); res.status(204).send(); } catch (e) { next(e); }
  }) satisfies RequestHandler,

  // Favorites
  getFavorites: (async (req, res, next) => {
    try { res.json(await usersService.getFavorites(userId(req))); } catch (e) { next(e); }
  }) satisfies RequestHandler,

  toggleFavorite: (async (req, res, next) => {
    try {
      const added = await usersService.toggleFavorite(userId(req), req.params.businessId);
      res.json({ added });
    } catch (e) { next(e); }
  }) satisfies RequestHandler,

  // Notifications
  getNotifications: (async (req, res, next) => {
    try { res.json(await usersService.getNotifications(userId(req))); } catch (e) { next(e); }
  }) satisfies RequestHandler,

  markNotificationRead: (async (req, res, next) => {
    try { await usersService.markNotificationRead(userId(req), req.params.id); res.status(204).send(); } catch (e) { next(e); }
  }) satisfies RequestHandler,

  markAllNotificationsRead: (async (req, res, next) => {
    try { await usersService.markAllNotificationsRead(userId(req)); res.status(204).send(); } catch (e) { next(e); }
  }) satisfies RequestHandler,

  deleteNotification: (async (req, res, next) => {
    try { await usersService.deleteNotification(userId(req), req.params.id); res.status(204).send(); } catch (e) { next(e); }
  }) satisfies RequestHandler,
};
