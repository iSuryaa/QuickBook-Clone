import { prisma } from "../../lib/prisma.js";

export const usersRepository = {
  findById: (id: string) =>
    prisma.user.findUnique({
      where: { id },
      select: { id: true, name: true, email: true, phone: true, role: true, createdAt: true },
    }),

  update: (id: string, data: { name?: string; email?: string }) =>
    prisma.user.update({
      where: { id },
      data,
      select: { id: true, name: true, email: true, phone: true, role: true },
    }),

  // ── Addresses ────────────────────────────────────────────
  findAddresses: (userId: string) =>
    prisma.address.findMany({ where: { userId } }),

  findAddressById: (id: string, userId: string) =>
    prisma.address.findFirst({ where: { id, userId } }),

  createAddress: (
    userId: string,
    data: {
      label: string;
      tag?: string;
      line1: string;
      line2?: string;
      city: string;
      pincode: string;
    },
  ) => prisma.address.create({ data: { userId, ...data } }),

  updateAddress: (
    id: string,
    data: {
      label?: string;
      tag?: string;
      line1?: string;
      line2?: string;
      city?: string;
      pincode?: string;
    },
  ) => prisma.address.update({ where: { id }, data }),

  deleteAddress: (id: string) => prisma.address.delete({ where: { id } }),

  // ── Saved cards ──────────────────────────────────────────
  findCards: (userId: string) =>
    prisma.savedCard.findMany({ where: { userId } }),

  createCard: (
    userId: string,
    data: {
      brand: string;
      maskedNumber: string;
      last4: string;
      cardholderName: string;
      expiryMmYy: string;
    },
  ) => prisma.savedCard.create({ data: { userId, ...data } }),

  deleteCard: (id: string, userId: string) =>
    prisma.savedCard.deleteMany({ where: { id, userId } }),

  // ── Favorites ────────────────────────────────────────────
  findFavorites: (userId: string) =>
    prisma.favorite.findMany({
      where: { userId },
      include: { business: { select: { id: true, name: true, imageUrl: true, category: true, rating: true } } },
    }),

  toggleFavorite: async (userId: string, businessId: string) => {
    const existing = await prisma.favorite.findUnique({
      where: { userId_businessId: { userId, businessId } },
    });
    if (existing) {
      await prisma.favorite.delete({ where: { id: existing.id } });
      return false; // removed
    }
    await prisma.favorite.create({ data: { userId, businessId } });
    return true; // added
  },

  // ── Notifications ────────────────────────────────────────
  findNotifications: (userId: string) =>
    prisma.notification.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 50,
    }),

  markNotificationRead: (id: string, userId: string) =>
    prisma.notification.updateMany({ where: { id, userId }, data: { read: true } }),

  markAllRead: (userId: string) =>
    prisma.notification.updateMany({ where: { userId, read: false }, data: { read: true } }),

  deleteNotification: (id: string, userId: string) =>
    prisma.notification.deleteMany({ where: { id, userId } }),
};
