import { prisma } from "../../lib/prisma.js";

export const staffRepository = {
  findByBusiness: (businessId: string) =>
    prisma.staff.findMany({
      where: { businessId },
      orderBy: { rating: "desc" },
    }),

  findById: (id: string) => prisma.staff.findUnique({ where: { id } }),

  findAvailableSlots: async (staffId: string, date: string, durationMins: number) => {
    // Get all bookings for this staff member on this date
    const existingBookings = await prisma.booking.findMany({
      where: {
        staffId,
        date,
        status: { notIn: ["CANCELLED"] },
      },
      include: { service: { select: { durationMins: true } } },
      orderBy: { time: "asc" },
    });

    // Generate all possible 30-min slots 9AM–9PM
    const allSlots: string[] = [];
    for (let h = 9; h < 21; h++) {
      for (const m of [0, 30]) {
        const hour12 = h % 12 === 0 ? 12 : h % 12;
        const ampm = h < 12 ? "AM" : "PM";
        allSlots.push(`${hour12}:${m === 0 ? "00" : m} ${ampm}`);
      }
    }

    // Mark booked slots as unavailable (simple exclusion based on time string)
    const bookedTimes = new Set(existingBookings.map((b) => b.time));
    return allSlots.map((slot) => ({ time: slot, available: !bookedTimes.has(slot) }));
  },
};
