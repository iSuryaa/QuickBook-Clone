import { staffRepository } from "./staff.repository.js";
import { NotFoundError } from "../../lib/errors.js";

export const staffService = {
  getByBusiness: (businessId: string) =>
    staffRepository.findByBusiness(businessId),

  async getAvailableSlots(staffId: string, date: string, durationMins: number) {
    const staff = await staffRepository.findById(staffId);
    if (!staff) throw new NotFoundError("Staff member");
    return staffRepository.findAvailableSlots(staffId, date, durationMins);
  },
};
