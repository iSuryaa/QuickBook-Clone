import type { RequestHandler } from "express";
import { staffService } from "./staff.service.js";

export const staffController = {
  getByBusiness: (async (req, res, next) => {
    try {
      res.json(await staffService.getByBusiness(req.params.businessId));
    } catch (e) { next(e); }
  }) satisfies RequestHandler,

  getAvailableSlots: (async (req, res, next) => {
    try {
      const { date, durationMins } = req.query;
      const slots = await staffService.getAvailableSlots(
        req.params.staffId,
        String(date),
        Number(durationMins) || 30,
      );
      res.json(slots);
    } catch (e) { next(e); }
  }) satisfies RequestHandler,
};
