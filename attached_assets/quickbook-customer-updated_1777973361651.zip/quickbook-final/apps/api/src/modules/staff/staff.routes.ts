import { Router } from "express";
import { staffController } from "./staff.controller.js";

const router = Router();

// GET /api/staff/business/:businessId
router.get("/business/:businessId", staffController.getByBusiness);

// GET /api/staff/:staffId/slots?date=YYYY-MM-DD&durationMins=60
router.get("/:staffId/slots", staffController.getAvailableSlots);

export default router;
