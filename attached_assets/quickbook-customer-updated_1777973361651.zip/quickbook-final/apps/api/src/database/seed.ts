/**
 * Database seed — mirrors the hardcoded BUSINESSES + MOVIES data from the
 * original monolithic App.tsx, so the refactored API returns the same data.
 *
 * Run with:  pnpm --filter @que/api run db:seed
 */

import { prisma } from "../lib/prisma.js";

const IMG = (url: string) =>
  `${url}${url.includes("?") ? "&" : "?"}auto=format&fit=crop&w=800&q=70`;

async function main() {
  console.log("🌱  Seeding database…");

  // Clear existing data in dependency order
  await prisma.payment.deleteMany();
  await prisma.booking.deleteMany();
  await prisma.review.deleteMany();
  await prisma.favorite.deleteMany();
  await prisma.staff.deleteMany();
  await prisma.service.deleteMany();
  await prisma.openHours.deleteMany();
  await prisma.business.deleteMany();
  await prisma.otpCode.deleteMany();
  await prisma.notification.deleteMany();
  await prisma.savedCard.deleteMany();
  await prisma.address.deleteMany();
  await prisma.user.deleteMany();

  // ── Demo user ──────────────────────────────────────────────
  const demoUser = await prisma.user.create({
    data: {
      phone: "9876543210",
      name: "Demo User",
      email: "demo@quebooking.com",
      role: "CUSTOMER",
    },
  });
  console.log(`  ✓ Demo user: ${demoUser.phone}`);

  // ── Businesses ─────────────────────────────────────────────
  const businesses = [
    {
      id: "b1",
      name: "City General Hospital",
      category: "hospital",
      rating: 4.5,
      reviewCount: 320,
      distanceKm: 1.2,
      priceLevel: 3,
      openNow: true,
      imageUrl: IMG("https://images.unsplash.com/photo-1586773860418-d37222d8fce3"),
      address: "14 Medical Drive",
      phone: "+1 (555) 100-2200",
      website: "citygeneral.health",
      description: "Multi-specialty hospital with 24/7 emergency, diagnostics, and inpatient care.",
      waitTimeMinutes: 22,
      queueCount: 6,
      photos: [
        IMG("https://images.unsplash.com/photo-1538108149393-fbbd81895907"),
        IMG("https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d"),
      ],
      amenities: ["24/7 Emergency", "Pharmacy", "Free Wi-Fi", "Parking", "Wheelchair access"],
      services: [
        { id: "b1s1", name: "General Consultation", durationMins: 30, priceInPaise: 50000 },
        { id: "b1s2", name: "Blood Test Package", durationMins: 15, priceInPaise: 80000 },
        { id: "b1s3", name: "X-Ray", durationMins: 20, priceInPaise: 120000 },
      ],
      staff: [
        { id: "b1st1", name: "Dr. Priya Patel", role: "General Physician", rating: 4.8 },
        { id: "b1st2", name: "Dr. Arjun Mehta", role: "Cardiologist", rating: 4.6 },
      ],
    },
    {
      id: "b2",
      name: "The Styling Studio",
      category: "salon",
      rating: 4.8,
      reviewCount: 612,
      distanceKm: 0.8,
      priceLevel: 3,
      openNow: true,
      imageUrl: IMG("https://images.unsplash.com/photo-1560066984-138dadb4c035"),
      address: "28 Bloom Street",
      phone: "+1 (555) 900-3344",
      website: "thestylingstudio.com",
      description: "Award-winning salon specialising in balayage, keratin treatments, and bridal styling.",
      waitTimeMinutes: 10,
      queueCount: 2,
      photos: [
        IMG("https://images.unsplash.com/photo-1522337360788-8b13dee7a37e"),
        IMG("https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f"),
      ],
      amenities: ["Complimentary beverages", "Wi-Fi", "Kids corner", "Parking"],
      services: [
        { id: "b2s1", name: "Haircut & Blowdry", durationMins: 60, priceInPaise: 80000 },
        { id: "b2s2", name: "Balayage", durationMins: 180, priceInPaise: 450000 },
        { id: "b2s3", name: "Keratin Treatment", durationMins: 120, priceInPaise: 600000 },
      ],
      staff: [
        { id: "b2st1", name: "Riley Chen", role: "Senior Stylist", rating: 4.9 },
        { id: "b2st2", name: "Jordan Blake", role: "Colourist", rating: 4.7 },
      ],
    },
    {
      id: "b3",
      name: "The Grand Meridian",
      category: "hotel",
      rating: 4.9,
      reviewCount: 1840,
      distanceKm: 2.1,
      priceLevel: 4,
      openNow: true,
      imageUrl: IMG("https://images.unsplash.com/photo-1566073771259-6a8506099945"),
      address: "1 Luxury Lane",
      phone: "+1 (555) 777-1100",
      website: "grandmeridian.com",
      description: "Five-star hotel with panoramic city views, Michelin-starred dining, and an infinity pool.",
      waitTimeMinutes: 0,
      queueCount: 0,
      photos: [
        IMG("https://images.unsplash.com/photo-1611892440504-42a792e24d32"),
        IMG("https://images.unsplash.com/photo-1582719508461-905c673771fd"),
      ],
      amenities: ["Pool", "Spa", "Concierge", "Valet Parking", "Room Service", "Gym"],
      services: [
        { id: "b3s1", name: "Deluxe Room (1 night)", durationMins: 1440, priceInPaise: 1200000 },
        { id: "b3s2", name: "Suite (1 night)", durationMins: 1440, priceInPaise: 2500000 },
        { id: "b3s3", name: "Spa Day Pass", durationMins: 480, priceInPaise: 350000 },
      ],
      staff: [],
    },
    {
      id: "b6",
      name: "Iron Forge Gym",
      category: "gym",
      rating: 4.4,
      reviewCount: 880,
      distanceKm: 0.5,
      priceLevel: 2,
      openNow: true,
      imageUrl: IMG("https://images.unsplash.com/photo-1534438327276-14e5300c3a48"),
      address: "55 Strength Ave",
      phone: "+1 (555) 200-7711",
      website: "ironforge.fit",
      description: "24/7 strength training gym with personal trainers, group classes, and recovery pods.",
      waitTimeMinutes: 0,
      queueCount: 0,
      photos: [
        IMG("https://images.unsplash.com/photo-1517836357463-d25dfeac3438"),
        IMG("https://images.unsplash.com/photo-1571902943202-507ec2618e8f"),
      ],
      amenities: ["24/7 Access", "Locker Rooms", "Sauna", "Parking", "PT Sessions"],
      services: [
        { id: "b6s1", name: "Day Pass", durationMins: 240, priceInPaise: 25000 },
        { id: "b6s2", name: "Personal Training (1 hr)", durationMins: 60, priceInPaise: 80000 },
        { id: "b6s3", name: "Group Class", durationMins: 60, priceInPaise: 20000 },
      ],
      staff: [
        { id: "b6st1", name: "Alex Rivera", role: "Head Trainer", rating: 4.8 },
      ],
    },
    {
      id: "b8",
      name: "Olive & Vine Bistro",
      category: "restaurant",
      rating: 4.7,
      reviewCount: 1530,
      distanceKm: 1.1,
      priceLevel: 3,
      openNow: true,
      imageUrl: IMG("https://images.unsplash.com/photo-1517248135467-4c7edcad34c4"),
      address: "77 Vine Street",
      phone: "+1 (555) 444-7700",
      website: "oliveandvine.com",
      description: "Mediterranean small plates, wood-fired pizzas, and a curated natural wine list.",
      waitTimeMinutes: 28,
      queueCount: 9,
      photos: [
        IMG("https://images.unsplash.com/photo-1414235077428-338989a2e8c0"),
        IMG("https://images.unsplash.com/photo-1552566626-52f8b828add9"),
      ],
      amenities: ["Outdoor seating", "Private dining", "Vegan options", "Reservations"],
      services: [
        { id: "b8s1", name: "Lunch Reservation", durationMins: 90, priceInPaise: 0 },
        { id: "b8s2", name: "Dinner Reservation", durationMins: 120, priceInPaise: 0 },
        { id: "b8s3", name: "Chef's Tasting Menu", durationMins: 150, priceInPaise: 150000 },
      ],
      staff: [],
    },
    {
      id: "b9",
      name: "Starlight Cinema",
      category: "entertainment",
      rating: 4.6,
      reviewCount: 940,
      distanceKm: 2.4,
      priceLevel: 2,
      openNow: true,
      imageUrl: IMG("https://images.unsplash.com/photo-1489599849927-2ee91cede3ba"),
      address: "12 Marquee Way",
      phone: "+1 (555) 999-1212",
      website: "starlightcinema.com",
      description: "Boutique cinema with reclining seats, premium snacks, and indie & blockbuster screenings.",
      waitTimeMinutes: 8,
      queueCount: 3,
      photos: [
        IMG("https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c"),
        IMG("https://images.unsplash.com/photo-1542204165-65bf26472b9b"),
      ],
      amenities: ["Recliner Seats", "Dolby Sound", "Premium Snacks", "Parking"],
      services: [
        { id: "b9s1", name: "Standard Seat", durationMins: 150, priceInPaise: 20000 },
        { id: "b9s2", name: "Premium Recliner", durationMins: 150, priceInPaise: 35000 },
        { id: "b9s3", name: "VIP Lounge", durationMins: 150, priceInPaise: 50000 },
      ],
      staff: [],
    },
    {
      id: "b10",
      name: "Smash Badminton Arena",
      category: "games",
      rating: 4.7,
      reviewCount: 412,
      distanceKm: 1.8,
      priceLevel: 2,
      openNow: true,
      imageUrl: IMG("https://images.unsplash.com/photo-1626224583764-f87db24ac4ea"),
      address: "21 Shuttle Lane",
      phone: "+1 (555) 220-3344",
      website: "smashbadminton.com",
      description: "8 wooden indoor courts with pro-grade lighting, racket rentals, and coaching.",
      waitTimeMinutes: 15,
      queueCount: 5,
      photos: [
        IMG("https://images.unsplash.com/photo-1551958219-acbc608c6377"),
        IMG("https://images.unsplash.com/photo-1531415074968-036ba1b575da"),
      ],
      amenities: ["Racket Rental", "Coaching", "Locker Rooms", "Cafeteria"],
      services: [
        { id: "b10s1", name: "Court (1 hr)", durationMins: 60, priceInPaise: 35000 },
        { id: "b10s2", name: "Court + Rackets (1 hr)", durationMins: 60, priceInPaise: 50000 },
        { id: "b10s3", name: "Coaching session (1 hr)", durationMins: 60, priceInPaise: 80000 },
      ],
      staff: [],
    },
  ] as const;

  for (const b of businesses) {
    const { services, staff, photos, amenities, ...businessData } = b;
    await prisma.business.create({
      data: {
        ...businessData,
        category: businessData.category as never,
        photos: [...photos],
        amenities: [...amenities],
        services: {
          create: services.map(({ id, ...s }) => ({ ...s })),
        },
        staff: {
          create: staff.map(({ id, ...s }) => ({ ...s })),
        },
        openHours: {
          create: {
            mon: "9:00 AM – 7:00 PM",
            tue: "9:00 AM – 7:00 PM",
            wed: "9:00 AM – 7:00 PM",
            thu: "9:00 AM – 7:00 PM",
            fri: "9:00 AM – 8:00 PM",
            sat: "10:00 AM – 8:00 PM",
            sun: "10:00 AM – 6:00 PM",
          },
        },
      },
    });
    console.log(`  ✓ Business: ${b.name}`);
  }

  // ── Sample reviews ─────────────────────────────────────────
  const b1 = await prisma.business.findFirst({ where: { id: "b1" } });
  const b2 = await prisma.business.findFirst({ where: { id: "b2" } });
  if (b1 && b2) {
    await prisma.review.createMany({
      data: [
        { userId: demoUser.id, businessId: b1.id, rating: 5, text: "Wait time was minimal and Dr. Patel was wonderful." },
        { userId: demoUser.id, businessId: b2.id, rating: 5, text: "Best balayage I've ever had. Riley is a wizard." },
      ],
    });
    console.log("  ✓ Sample reviews");
  }

  console.log("\n✅  Seed complete!");
}

main()
  .catch((err) => {
    console.error("Seed failed:", err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
