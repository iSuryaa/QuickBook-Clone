import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: ["@que/shared", "@que/types", "@que/utils"],
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "images.unsplash.com" },
    ],
  },
  // Allow the app to call the API on the same host in production
  async rewrites() {
    return [
      {
        source: "/api/:path*",
        destination: `${process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3001"}/api/:path*`,
      },
    ];
  },
};

export default nextConfig;
