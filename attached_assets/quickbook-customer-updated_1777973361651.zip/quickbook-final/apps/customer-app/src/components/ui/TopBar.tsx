"use client";

import { ChevronLeft } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

interface TopBarProps {
  title: string;
  onBack?: () => void;
  right?: ReactNode;
  className?: string;
}

export function TopBar({ title, onBack, right, className }: TopBarProps) {
  return (
    <div className={cn("flex items-center gap-3 px-5 pt-12 pb-4 bg-white/80 backdrop-blur sticky top-0 z-10", className)}>
      {onBack && (
        <button
          onClick={onBack}
          className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center shrink-0"
          aria-label="Go back"
        >
          <ChevronLeft size={20} />
        </button>
      )}
      <h1 className="flex-1 text-lg font-bold truncate">{title}</h1>
      {right && <div className="shrink-0">{right}</div>}
    </div>
  );
}
