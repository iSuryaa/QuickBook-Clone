"use client";

import { Home, Search, Calendar, User } from "lucide-react";
import { cn } from "@/lib/utils";

export type TabName = "home" | "explore" | "bookings" | "profile";

interface BottomNavProps {
  activeTab: TabName;
  onTabChange: (tab: TabName) => void;
  bookingCount?: number;
}

const TABS = [
  { id: "home" as TabName, label: "Home", icon: Home },
  { id: "explore" as TabName, label: "Explore", icon: Search },
  { id: "bookings" as TabName, label: "Bookings", icon: Calendar },
  { id: "profile" as TabName, label: "Profile", icon: User },
] as const;

export function BottomNav({ activeTab, onTabChange, bookingCount }: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-[480px] mx-auto bg-white border-t border-slate-100 flex z-20">
      {TABS.map(({ id, label, icon: Icon }) => {
        const isActive = activeTab === id;
        const showBadge = id === "bookings" && bookingCount && bookingCount > 0;
        return (
          <button
            key={id}
            onClick={() => onTabChange(id)}
            className={cn(
              "flex-1 flex flex-col items-center gap-1 py-3 transition-colors",
              isActive ? "text-indigo-500" : "text-slate-400",
            )}
          >
            <div className="relative">
              <Icon size={22} strokeWidth={isActive ? 2.5 : 1.8} />
              {showBadge && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-indigo-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                  {bookingCount > 9 ? "9+" : bookingCount}
                </span>
              )}
            </div>
            <span className={cn("text-[10px] font-medium", isActive ? "font-bold" : "")}>
              {label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
