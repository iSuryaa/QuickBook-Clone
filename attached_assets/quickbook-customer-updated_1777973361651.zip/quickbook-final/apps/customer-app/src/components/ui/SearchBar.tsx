"use client";

import { Search, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  autoFocus?: boolean;
}

export function SearchBar({ value, onChange, placeholder = "Search…", className, autoFocus }: SearchBarProps) {
  return (
    <div className={cn(
      "flex items-center gap-2.5 bg-white rounded-2xl px-4 py-3 border border-slate-100 shadow-sm",
      className,
    )}>
      <Search size={17} className="text-slate-400 shrink-0" />
      <input
        type="search"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        autoFocus={autoFocus}
        className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate-400"
      />
      {value && (
        <button onClick={() => onChange("")} className="text-slate-400">
          <X size={15} />
        </button>
      )}
    </div>
  );
}
