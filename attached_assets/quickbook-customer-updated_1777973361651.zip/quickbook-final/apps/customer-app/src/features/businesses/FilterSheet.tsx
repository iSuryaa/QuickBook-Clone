"use client";

import { useState } from "react";
import { X, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Filters, PriceLevel } from "@que/types";

interface FilterSheetProps {
  filters: Filters;
  onApply: (filters: Filters) => void;
  onClose: () => void;
}

const PRICE_LEVELS: PriceLevel[] = [1, 2, 3, 4];
const PRICE_LABELS: Record<PriceLevel, string> = { 1: "₹", 2: "₹₹", 3: "₹₹₹", 4: "₹₹₹₹" };
const RATINGS = [0, 3, 3.5, 4, 4.5] as const;

export function FilterSheet({ filters, onApply, onClose }: FilterSheetProps) {
  const [draft, setDraft] = useState<Filters>(filters);

  const togglePrice = (level: PriceLevel) => {
    setDraft((prev) => ({
      ...prev,
      priceLevels: prev.priceLevels.includes(level)
        ? prev.priceLevels.filter((p) => p !== level)
        : [...prev.priceLevels, level],
    }));
  };

  const activeFilterCount =
    (draft.minRating > 0 ? 1 : 0) +
    (draft.maxDistanceKm < 10 ? 1 : 0) +
    (draft.openOnly ? 1 : 0) +
    (draft.priceLevels.length < 4 ? 1 : 0);

  const reset = () =>
    setDraft({ minRating: 0, maxDistanceKm: 10, openOnly: false, priceLevels: [1, 2, 3, 4] });

  return (
    <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50">
      <div className="bg-white w-full max-w-lg rounded-t-3xl max-h-[85vh] overflow-y-auto">
        {/* Handle + header */}
        <div className="sticky top-0 bg-white px-5 pt-4 pb-3 border-b border-slate-100">
          <div className="w-10 h-1 bg-slate-200 rounded-full mx-auto mb-4" />
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold">Filters {activeFilterCount > 0 && <span className="text-indigo-500">({activeFilterCount})</span>}</h2>
            <button onClick={onClose} className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center">
              <X size={16} />
            </button>
          </div>
        </div>

        <div className="px-5 py-5 flex flex-col gap-7">
          {/* Minimum rating */}
          <section>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-3">Minimum rating</p>
            <div className="flex gap-2 flex-wrap">
              {RATINGS.map((r) => (
                <button
                  key={r}
                  onClick={() => setDraft((d) => ({ ...d, minRating: r }))}
                  className={cn(
                    "flex items-center gap-1 px-3 py-1.5 rounded-full text-sm font-medium border transition-colors",
                    draft.minRating === r
                      ? "bg-indigo-500 text-white border-indigo-500"
                      : "bg-white text-slate-600 border-slate-200",
                  )}
                >
                  {r === 0 ? "Any" : (<><Star size={12} className="fill-current" />{r}+</>)}
                </button>
              ))}
            </div>
          </section>

          {/* Max distance */}
          <section>
            <div className="flex justify-between mb-3">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wide">Max distance</p>
              <p className="text-sm font-semibold text-indigo-500">
                {draft.maxDistanceKm >= 10 ? "Any" : `${draft.maxDistanceKm} km`}
              </p>
            </div>
            <input
              type="range"
              min={1}
              max={10}
              step={0.5}
              value={draft.maxDistanceKm}
              onChange={(e) => setDraft((d) => ({ ...d, maxDistanceKm: Number(e.target.value) }))}
              className="w-full accent-indigo-500"
            />
            <div className="flex justify-between text-xs text-slate-400 mt-1">
              <span>1 km</span><span>10 km</span>
            </div>
          </section>

          {/* Open now */}
          <section>
            <button
              onClick={() => setDraft((d) => ({ ...d, openOnly: !d.openOnly }))}
              className="flex items-center justify-between w-full"
            >
              <span className="text-sm font-medium">Open now only</span>
              <div className={cn(
                "w-11 h-6 rounded-full relative transition-colors",
                draft.openOnly ? "bg-indigo-500" : "bg-slate-200",
              )}>
                <div className={cn(
                  "absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all",
                  draft.openOnly ? "left-6" : "left-1",
                )} />
              </div>
            </button>
          </section>

          {/* Price level */}
          <section>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-3">Price level</p>
            <div className="flex gap-2">
              {PRICE_LEVELS.map((level) => (
                <button
                  key={level}
                  onClick={() => togglePrice(level)}
                  className={cn(
                    "flex-1 py-2 rounded-xl text-sm font-semibold border transition-colors",
                    draft.priceLevels.includes(level)
                      ? "bg-indigo-500 text-white border-indigo-500"
                      : "bg-white text-slate-500 border-slate-200",
                  )}
                >
                  {PRICE_LABELS[level]}
                </button>
              ))}
            </div>
          </section>
        </div>

        {/* Footer actions */}
        <div className="sticky bottom-0 bg-white border-t border-slate-100 px-5 py-4 flex gap-3">
          <button
            onClick={reset}
            className="flex-1 py-3 rounded-2xl border border-slate-200 text-sm font-semibold text-slate-600"
          >
            Reset
          </button>
          <button
            onClick={() => { onApply(draft); onClose(); }}
            className="flex-1 py-3 rounded-2xl bg-indigo-500 text-white text-sm font-semibold"
          >
            Apply {activeFilterCount > 0 && `(${activeFilterCount})`}
          </button>
        </div>
      </div>
    </div>
  );
}
