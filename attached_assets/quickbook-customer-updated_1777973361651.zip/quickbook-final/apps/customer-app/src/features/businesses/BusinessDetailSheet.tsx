"use client";

import { useState } from "react";
import {
  X, Star, MapPin, Clock, Phone, Globe, Heart,
  ChevronRight, Users, CheckCircle2, Info,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { formatINR, formatPriceLevel, formatDuration } from "@que/utils";
import { useBusiness, useBusinessReviews } from "./use-businesses";
import { useToggleFavorite, useFavorites } from "@/features/profile/use-profile";
import { Skeleton } from "@/components/ui/Skeleton";
import type { Business, Service, StaffMember } from "@que/types";
import { useMemo } from "react";

interface BusinessDetailSheetProps {
  businessId: string;
  onClose: () => void;
  onBook: (business: Business, service?: Service, staff?: StaffMember) => void;
}

export function BusinessDetailSheet({ businessId, onClose, onBook }: BusinessDetailSheetProps) {
  const { data: business, isLoading } = useBusiness(businessId);
  const { data: reviewsData } = useBusinessReviews(businessId);
  const { data: favData } = useFavorites();
  const toggleFav = useToggleFavorite();
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [activeTab, setActiveTab] = useState<"overview" | "services" | "reviews">("overview");

  const favoriteIds = useMemo(
    () => (favData as { business: { id: string } }[] | undefined)?.map((f) => f.business.id) ?? [],
    [favData],
  );
  const isFavorite = business ? favoriteIds.includes(business.id) : false;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50">
      <div
        className="bg-slate-50 w-full max-w-[480px] rounded-t-3xl max-h-[92vh] flex flex-col animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Hero image */}
        <div className="relative h-52 shrink-0 rounded-t-3xl overflow-hidden">
          {isLoading ? (
            <Skeleton className="h-full w-full rounded-none" />
          ) : (
            <>
              <img
                src={business?.imageUrl}
                alt={business?.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            </>
          )}

          {/* Close */}
          <button
            onClick={onClose}
            className="absolute top-4 left-4 w-9 h-9 rounded-full bg-black/30 backdrop-blur-sm flex items-center justify-center text-white"
          >
            <X size={18} />
          </button>

          {/* Favourite */}
          {business && (
            <button
              onClick={() => toggleFav.mutate(business.id)}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/30 backdrop-blur-sm flex items-center justify-center"
            >
              <Heart
                size={18}
                className={cn(isFavorite ? "text-red-400 fill-red-400" : "text-white")}
              />
            </button>
          )}

          {/* Bottom meta */}
          {business && (
            <div className="absolute bottom-4 left-4 right-4">
              <div className="flex items-end justify-between gap-2">
                <div>
                  <h2 className="text-white font-bold text-xl leading-tight">{business.name}</h2>
                  <p className="text-white/80 text-xs mt-0.5">{business.address}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className={cn(
                    "text-xs font-semibold px-2 py-0.5 rounded-full",
                    business.openNow ? "bg-emerald-500/90 text-white" : "bg-slate-500/80 text-white",
                  )}>
                    {business.openNow ? "Open" : "Closed"}
                  </span>
                  {business.openNow && business.queueCount > 0 && (
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-500/90 text-white">
                      {business.queueCount} in queue
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Quick stats */}
        {isLoading ? (
          <div className="px-5 py-3 flex gap-4">
            {[1, 2, 3].map((i) => <Skeleton key={i} className="h-10 flex-1 rounded-xl" />)}
          </div>
        ) : business && (
          <div className="bg-white px-5 py-3 flex items-center gap-0 border-b border-slate-100">
            <StatPill icon={<Star size={13} className="text-amber-400 fill-amber-400" />}
              value={business.rating.toFixed(1)}
              sub={`(${business.reviewCount})`} />
            <div className="w-px h-8 bg-slate-100 mx-3" />
            <StatPill icon={<MapPin size={13} className="text-indigo-400" />}
              value={`${business.distanceKm} km`}
              sub="away" />
            <div className="w-px h-8 bg-slate-100 mx-3" />
            <StatPill icon={<Clock size={13} className="text-emerald-500" />}
              value={business.waitTimeMinutes > 0 ? `~${business.waitTimeMinutes} min` : "No wait"}
              sub="wait time" />
            <div className="w-px h-8 bg-slate-100 mx-3" />
            <StatPill icon={<span className="text-slate-500 text-xs font-bold">₹</span>}
              value={formatPriceLevel(business.priceLevel)}
              sub="price" />
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white flex border-b border-slate-100 shrink-0">
          {(["overview", "services", "reviews"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "flex-1 py-3 text-xs font-semibold capitalize transition-colors",
                activeTab === tab
                  ? "text-indigo-500 border-b-2 border-indigo-500"
                  : "text-slate-400",
              )}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Scrollable content */}
        <div className="flex-1 overflow-y-auto">
          {/* OVERVIEW */}
          {activeTab === "overview" && business && (
            <div className="px-5 py-4 flex flex-col gap-5 pb-32">
              {business.description && (
                <section>
                  <SectionTitle>About</SectionTitle>
                  <p className="text-sm text-slate-600 leading-relaxed">{business.description}</p>
                </section>
              )}

              {/* Contact */}
              <section>
                <SectionTitle>Contact</SectionTitle>
                <div className="flex flex-col gap-2">
                  {business.phone && (
                    <a href={`tel:${business.phone}`} className="flex items-center gap-3 text-sm text-slate-600">
                      <Phone size={15} className="text-indigo-400 shrink-0" />
                      {business.phone}
                    </a>
                  )}
                  {business.website && (
                    <a href={business.website} target="_blank" rel="noreferrer"
                      className="flex items-center gap-3 text-sm text-indigo-500 font-medium">
                      <Globe size={15} className="shrink-0" />
                      Visit website
                    </a>
                  )}
                  <div className="flex items-center gap-3 text-sm text-slate-600">
                    <MapPin size={15} className="text-indigo-400 shrink-0" />
                    {business.address}
                  </div>
                </div>
              </section>

              {/* Open hours */}
              {business.openHours && (
                <section>
                  <SectionTitle>Opening hours</SectionTitle>
                  <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
                    {Object.entries(business.openHours).map(([day, hours], i, arr) => (
                      <div
                        key={day}
                        className={cn(
                          "flex items-center justify-between px-4 py-2.5 text-sm",
                          i < arr.length - 1 && "border-b border-slate-50",
                        )}
                      >
                        <span className="font-medium text-slate-700">{day}</span>
                        <span className="text-slate-500 font-mono text-xs">{hours}</span>
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Amenities */}
              {business.amenities && business.amenities.length > 0 && (
                <section>
                  <SectionTitle>Amenities</SectionTitle>
                  <div className="flex flex-wrap gap-2">
                    {business.amenities.map((a) => (
                      <span key={a} className="flex items-center gap-1 bg-white border border-slate-100 text-xs text-slate-600 px-3 py-1.5 rounded-full font-medium">
                        <CheckCircle2 size={11} className="text-emerald-500" />
                        {a}
                      </span>
                    ))}
                  </div>
                </section>
              )}
            </div>
          )}

          {/* SERVICES */}
          {activeTab === "services" && business && (
            <div className="px-5 py-4 pb-32 flex flex-col gap-3">
              {isLoading ? (
                Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-2xl" />)
              ) : business.services?.length === 0 ? (
                <p className="text-sm text-slate-400 text-center py-8">No services listed</p>
              ) : (
                business.services?.map((service) => (
                  <button
                    key={service.id}
                    onClick={() => setSelectedService(
                      selectedService?.id === service.id ? null : service
                    )}
                    className={cn(
                      "w-full bg-white rounded-2xl border p-4 text-left transition-all",
                      selectedService?.id === service.id
                        ? "border-indigo-400 shadow-sm shadow-indigo-100"
                        : "border-slate-100",
                    )}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm">{service.name}</p>
                        <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                          <span className="flex items-center gap-1">
                            <Clock size={11} /> {formatDuration(service.duration)}
                          </span>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <span className="font-bold text-sm text-slate-800">
                          {formatINR(service.price / 100)}
                        </span>
                        <div className={cn(
                          "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all",
                          selectedService?.id === service.id
                            ? "border-indigo-500 bg-indigo-500"
                            : "border-slate-300",
                        )}>
                          {selectedService?.id === service.id && (
                            <CheckCircle2 size={12} className="text-white" />
                          )}
                        </div>
                      </div>
                    </div>
                  </button>
                ))
              )}

              {/* Staff picker (only if a service is chosen) */}
              {selectedService && business.staff?.length > 0 && (
                <section className="mt-2">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-2 px-1">
                    Choose staff (optional)
                  </p>
                  <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1">
                    {[{ id: null, name: "Any available", role: "", rating: 0 } as unknown as StaffMember,
                      ...business.staff].map((member) => (
                      <button
                        key={member.id ?? "any"}
                        onClick={() => setSelectedStaff(
                          member.id === null ? null :
                            (selectedStaff?.id === member.id ? null : member)
                        )}
                        className={cn(
                          "flex flex-col items-center gap-1.5 p-3 rounded-2xl border shrink-0 w-20 transition-all",
                          (member.id === null ? !selectedStaff : selectedStaff?.id === member.id)
                            ? "border-indigo-400 bg-indigo-50"
                            : "border-slate-100 bg-white",
                        )}
                      >
                        <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center">
                          <span className="text-sm font-bold text-indigo-500">
                            {member.name.charAt(0)}
                          </span>
                        </div>
                        <p className="text-[10px] font-medium text-center leading-tight line-clamp-2">
                          {member.name}
                        </p>
                        {member.rating > 0 && (
                          <span className="text-[9px] text-amber-500 font-semibold flex items-center gap-0.5">
                            <Star size={8} className="fill-amber-400" />{member.rating.toFixed(1)}
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                </section>
              )}
            </div>
          )}

          {/* REVIEWS */}
          {activeTab === "reviews" && (
            <div className="px-5 py-4 pb-32 flex flex-col gap-3">
              {!reviewsData ? (
                Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-2xl" />)
              ) : (reviewsData as unknown as { data: { id: string; author: string; rating: number; text: string; date: string }[] })?.data?.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-slate-400">
                  <Star size={28} className="mb-2" />
                  <p className="text-sm font-medium">No reviews yet</p>
                </div>
              ) : (
                (reviewsData as unknown as { data: { id: string; author: string; rating: number; text: string; date: string }[] })?.data?.map((review) => (
                  <div key={review.id} className="bg-white rounded-2xl border border-slate-100 p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center">
                          <span className="text-xs font-bold text-indigo-500">
                            {review.author.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <p className="text-xs font-semibold">{review.author}</p>
                          <p className="text-[10px] text-slate-400">{review.date}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            size={11}
                            className={cn(
                              i < review.rating ? "text-amber-400 fill-amber-400" : "text-slate-200",
                            )}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-sm text-slate-600 leading-relaxed">{review.text}</p>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Sticky CTA */}
        {business && (
          <div className="shrink-0 bg-white border-t border-slate-100 px-5 py-4 pb-safe">
            <div className="flex items-center gap-3">
              {business.waitTimeMinutes > 0 && (
                <div className="flex items-center gap-1.5 bg-amber-50 text-amber-700 px-3 py-2 rounded-xl text-xs font-medium">
                  <Users size={13} />
                  ~{business.waitTimeMinutes} min wait
                </div>
              )}
              <button
                onClick={() => business && onBook(business, selectedService ?? undefined, selectedStaff ?? undefined)}
                disabled={!business.openNow}
                className={cn(
                  "flex-1 py-3.5 rounded-2xl font-bold text-sm transition-all",
                  business.openNow
                    ? "bg-indigo-500 text-white active:scale-[0.98]"
                    : "bg-slate-200 text-slate-400 cursor-not-allowed",
                )}
              >
                {business.openNow
                  ? selectedService
                    ? `Book ${selectedService.name}`
                    : "Book Appointment"
                  : "Currently Closed"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function StatPill({ icon, value, sub }: { icon: React.ReactNode; value: string; sub: string }) {
  return (
    <div className="flex flex-col items-center gap-0.5 flex-1">
      <div className="flex items-center gap-1">
        {icon}
        <span className="text-xs font-bold text-slate-800">{value}</span>
      </div>
      <span className="text-[9px] text-slate-400">{sub}</span>
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-2">{children}</p>
  );
}
