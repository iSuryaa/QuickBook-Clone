"use client";

import { Star, Clock, MapPin, Heart } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatINR, formatPriceLevel } from "@que/utils";
import type { Business } from "@que/types";

interface BusinessCardProps {
  business: Business;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onClick: (id: string) => void;
  variant?: "default" | "compact";
}

export function BusinessCard({
  business,
  isFavorite,
  onToggleFavorite,
  onClick,
  variant = "default",
}: BusinessCardProps) {
  if (variant === "compact") {
    return <CompactCard business={business} isFavorite={isFavorite} onToggleFavorite={onToggleFavorite} onClick={onClick} />;
  }
  return <DefaultCard business={business} isFavorite={isFavorite} onToggleFavorite={onToggleFavorite} onClick={onClick} />;
}

function DefaultCard({ business, isFavorite, onToggleFavorite, onClick }: Omit<BusinessCardProps, "variant">) {
  return (
    <button
      onClick={() => onClick(business.id)}
      className="w-full bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-100 text-left transition-transform active:scale-[0.98]"
    >
      {/* Image */}
      <div className="relative h-44">
        <img
          src={business.imageUrl}
          alt={business.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />

        {/* Favorite button */}
        <button
          onClick={(e) => { e.stopPropagation(); onToggleFavorite(business.id); }}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 flex items-center justify-center shadow"
        >
          <Heart
            size={15}
            className={cn(isFavorite ? "text-red-500 fill-red-500" : "text-slate-400")}
          />
        </button>

        {/* Open/closed badge */}
        <span className={cn(
          "absolute bottom-3 left-3 text-xs font-semibold px-2 py-0.5 rounded-full",
          business.openNow
            ? "bg-emerald-500/90 text-white"
            : "bg-slate-500/80 text-white",
        )}>
          {business.openNow ? "Open" : "Closed"}
        </span>

        {/* Queue badge */}
        {business.openNow && business.queueCount > 0 && (
          <span className="absolute bottom-3 right-3 bg-indigo-500/90 text-white text-xs font-semibold px-2 py-0.5 rounded-full">
            {business.queueCount} in queue
          </span>
        )}
      </div>

      {/* Body */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-1">
          <h3 className="font-semibold text-sm leading-tight">{business.name}</h3>
          <span className="text-xs text-slate-400 shrink-0">{formatPriceLevel(business.priceLevel)}</span>
        </div>

        <div className="flex items-center gap-3 text-xs text-slate-500 mt-1.5">
          <span className="flex items-center gap-1">
            <Star size={11} className="text-amber-400 fill-amber-400" />
            {business.rating.toFixed(1)}
            <span className="text-slate-400">({business.reviewCount})</span>
          </span>
          <span className="flex items-center gap-1">
            <MapPin size={11} />
            {business.distanceKm} km
          </span>
          {business.waitTimeMinutes > 0 && (
            <span className="flex items-center gap-1">
              <Clock size={11} />
              ~{business.waitTimeMinutes} min wait
            </span>
          )}
        </div>

        <p className="text-xs text-slate-400 mt-2 line-clamp-1">{business.address}</p>
      </div>
    </button>
  );
}

function CompactCard({ business, isFavorite, onToggleFavorite, onClick }: Omit<BusinessCardProps, "variant">) {
  return (
    <button
      onClick={() => onClick(business.id)}
      className="flex items-center gap-3 w-full bg-white rounded-2xl p-3 border border-slate-100 text-left active:scale-[0.98] transition-transform"
    >
      <img
        src={business.imageUrl}
        alt={business.name}
        className="w-14 h-14 rounded-xl object-cover shrink-0"
      />
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-sm truncate">{business.name}</p>
        <p className="text-xs text-slate-400 truncate">{business.address}</p>
        <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
          <span className="flex items-center gap-0.5">
            <Star size={10} className="text-amber-400 fill-amber-400" />
            {business.rating.toFixed(1)}
          </span>
          <span>{business.distanceKm} km</span>
          <span className={cn("font-medium", business.openNow ? "text-emerald-500" : "text-slate-400")}>
            {business.openNow ? "Open" : "Closed"}
          </span>
        </div>
      </div>
      <button
        onClick={(e) => { e.stopPropagation(); onToggleFavorite(business.id); }}
        className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center"
      >
        <Heart size={15} className={cn(isFavorite ? "text-red-500 fill-red-500" : "text-slate-300")} />
      </button>
    </button>
  );
}
