"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { businessesService, type BusinessListParams } from "./businesses.service";
import { useAuth } from "@/features/auth/use-auth";

export const businessKeys = {
  all: ["businesses"] as const,
  list: (params: BusinessListParams) => [...businessKeys.all, "list", params] as const,
  detail: (id: string) => [...businessKeys.all, "detail", id] as const,
  reviews: (id: string) => [...businessKeys.all, "reviews", id] as const,
};

export function useBusinesses(params: BusinessListParams = {}) {
  return useQuery({
    queryKey: businessKeys.list(params),
    queryFn: () => businessesService.list(params),
    staleTime: 1000 * 60 * 3,
  });
}

export function useBusiness(id: string) {
  return useQuery({
    queryKey: businessKeys.detail(id),
    queryFn: () => businessesService.getById(id),
    enabled: Boolean(id),
  });
}

export function useBusinessReviews(businessId: string) {
  return useQuery({
    queryKey: businessKeys.reviews(businessId),
    queryFn: () => businessesService.getReviews(businessId),
    enabled: Boolean(businessId),
  });
}

export function useAddReview(businessId: string) {
  const { token } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { rating: number; text: string }) =>
      businessesService.addReview(businessId, data, token!),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: businessKeys.reviews(businessId) });
      qc.invalidateQueries({ queryKey: businessKeys.detail(businessId) });
    },
  });
}
