import { apiClient } from "@/lib/api-client";
import type { Business, PaginatedResponse } from "@que/types";

export interface BusinessListParams {
  category?: string;
  search?: string;
  openOnly?: boolean;
  minRating?: number;
  page?: number;
  pageSize?: number;
}

export const businessesService = {
  list: (params: BusinessListParams = {}, token?: string) => {
    const qs = new URLSearchParams();
    if (params.category) qs.set("category", params.category);
    if (params.search) qs.set("search", params.search);
    if (params.openOnly) qs.set("openOnly", "true");
    if (params.minRating) qs.set("minRating", String(params.minRating));
    if (params.page) qs.set("page", String(params.page));
    if (params.pageSize) qs.set("pageSize", String(params.pageSize));
    const query = qs.toString();
    return apiClient.get<PaginatedResponse<Business>>(
      `/businesses${query ? `?${query}` : ""}`,
      token,
    );
  },

  getById: (id: string, token?: string) =>
    apiClient.get<Business & { services: Business["services"]; staff: Business["staff"] }>(
      `/businesses/${id}`,
      token,
    ),

  getReviews: (businessId: string, page = 1) =>
    apiClient.get(`/businesses/${businessId}/reviews?page=${page}`),

  addReview: (businessId: string, data: { rating: number; text: string }, token: string) =>
    apiClient.post(`/businesses/${businessId}/reviews`, data, token),
};
