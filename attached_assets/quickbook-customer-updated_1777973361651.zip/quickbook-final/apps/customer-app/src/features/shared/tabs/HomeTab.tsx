"use client";

import { useMemo } from "react";
import { Bell, MapPin, ChevronRight, Hospital, Scissors, Building2, Dumbbell, UtensilsCrossed, Ticket } from "lucide-react";
import { SearchBar } from "@/components/ui/SearchBar";
import { BusinessCard } from "@/features/businesses/BusinessCard";
import { BusinessCardSkeleton } from "@/components/ui/Skeleton";
import { useBusinesses } from "@/features/businesses/use-businesses";
import { useNotifications, useToggleFavorite, useFavorites } from "@/features/profile/use-profile";
import { useAuth } from "@/features/auth/use-auth";
import type { CategoryId } from "@que/types";

const CATEGORIES = [
  { id: "hospital" as CategoryId, name: "Hospital", icon: Hospital, color: "#ef4444" },
  { id: "salon" as CategoryId, name: "Salon", icon: Scissors, color: "#ec4899" },
  { id: "hotel" as CategoryId, name: "Hotel", icon: Building2, color: "#3b82f6" },
  { id: "gym" as CategoryId, name: "Gym", icon: Dumbbell, color: "#10b981" },
  { id: "restaurant" as CategoryId, name: "Restaurant", icon: UtensilsCrossed, color: "#f59e0b" },
  { id: "entertainment" as CategoryId, name: "Cinema", icon: Ticket, color: "#a855f7" },
];

interface HomeTabProps {
  onGoExplore: (category?: string) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onViewBusiness: (id: string) => void;
  onOpenNotifications: () => void;
}

export function HomeTab({ onGoExplore, searchQuery, onSearchChange, onViewBusiness, onOpenNotifications }: HomeTabProps) {
  const { user, isLoggedIn } = useAuth();
  const { data: businesses, isLoading } = useBusinesses({ pageSize: 10 });
  const { data: notifs } = useNotifications();
  const { data: favData } = useFavorites();
  const toggleFav = useToggleFavorite();

  const unreadCount = notifs?.filter((n) => !n.read).length ?? 0;
  const favoriteIds: string[] = useMemo(
    () => (favData as { business: { id: string } }[] | undefined)?.map((f) => f.business.id) ?? [],
    [favData],
  );

  const featured = businesses?.data?.slice(0, 5) ?? [];
  const popular = businesses?.data?.slice(2, 7) ?? [];

  return (
    <div className="px-5 pt-12">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <p className="text-xs text-slate-500 flex items-center gap-1">
            <MapPin size={11} /> Nearby
          </p>
          <h1 className="text-2xl font-bold mt-0.5">
            {isLoggedIn ? `Hi, ${user?.name.split(" ")[0]} 👋` : "Good day!"}
          </h1>
        </div>
        <button
          onClick={onOpenNotifications}
          className="relative w-9 h-9 rounded-full bg-white border border-slate-100 flex items-center justify-center shadow-sm"
        >
          <Bell size={18} className="text-slate-600" />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-indigo-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </button>
      </div>

      {/* Search — navigates to Explore on type */}
      <SearchBar
        value={searchQuery}
        onChange={onSearchChange}
        placeholder="Search businesses, services…"
        className="mb-6"
      />

      {/* Categories */}
      <section className="mb-7">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-bold text-base">Categories</h2>
          <button onClick={() => onGoExplore()} className="text-xs text-indigo-500 font-medium flex items-center gap-0.5">
            All <ChevronRight size={13} />
          </button>
        </div>
        <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1">
          {CATEGORIES.map(({ id, name, icon: Icon, color }) => (
            <button
              key={id}
              onClick={() => onGoExplore(id)}
              className="flex flex-col items-center gap-2 shrink-0"
            >
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{ backgroundColor: `${color}18` }}>
                <Icon size={24} style={{ color }} />
              </div>
              <span className="text-xs font-medium text-slate-600">{name}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Featured */}
      <section className="mb-7">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-bold text-base">Featured</h2>
          <button onClick={() => onGoExplore()} className="text-xs text-indigo-500 font-medium flex items-center gap-0.5">
            See all <ChevronRight size={13} />
          </button>
        </div>
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-1">
          {isLoading
            ? Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="w-64 shrink-0"><BusinessCardSkeleton /></div>
              ))
            : featured.map((business) => (
                <div key={business.id} className="w-64 shrink-0">
                  <BusinessCard
                    business={business}
                    isFavorite={favoriteIds.includes(business.id)}
                    onToggleFavorite={(id) => toggleFav.mutate(id)}
                    onClick={onViewBusiness}
                  />
                </div>
              ))}
        </div>
      </section>

      {/* Popular nearby */}
      <section className="mb-7">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-bold text-base">Popular nearby</h2>
        </div>
        <div className="flex flex-col gap-3">
          {isLoading
            ? Array.from({ length: 4 }).map((_, i) => <BusinessCardSkeleton key={i} />)
            : popular.map((business) => (
                <BusinessCard
                  key={business.id}
                  business={business}
                  variant="compact"
                  isFavorite={favoriteIds.includes(business.id)}
                  onToggleFavorite={(id) => toggleFav.mutate(id)}
                  onClick={onViewBusiness}
                />
              ))}
        </div>
      </section>
    </div>
  );
}
