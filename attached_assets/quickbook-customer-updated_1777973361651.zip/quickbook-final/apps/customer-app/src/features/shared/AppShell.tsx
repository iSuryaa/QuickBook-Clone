"use client";

import { useState, useCallback } from "react";
import { BottomNav, type TabName } from "@/components/ui/BottomNav";
import { HomeTab } from "./tabs/HomeTab";
import { ExploreTab } from "./tabs/ExploreTab";
import { BookingsTab } from "./tabs/BookingsTab";
import { ProfileTab } from "./tabs/ProfileTab";
import { BusinessDetailSheet } from "@/features/businesses/BusinessDetailSheet";
import { BookingFlowSheet } from "@/features/bookings/BookingFlowSheet";
import { QueueTrackerSheet } from "@/features/bookings/QueueTrackerSheet";
import { NotificationsPanel } from "@/features/profile/NotificationsPanel";
import { EditProfileSheet } from "@/features/profile/EditProfileSheet";
import { AddressesSheet } from "@/features/profile/AddressesSheet";
import { FavouritesSheet } from "@/features/profile/FavouritesSheet";
import { useBookings } from "@/features/bookings/use-bookings";
import { useAuth } from "@/features/auth/use-auth";
import { LoginScreen } from "@/features/auth/LoginScreen";
import type { Filters, Business, Service, StaffMember } from "@que/types";

const DEFAULT_FILTERS: Filters = {
  minRating: 0,
  maxDistanceKm: 10,
  openOnly: false,
  priceLevels: [1, 2, 3, 4],
};

type ModalType =
  | { type: "businessDetail"; businessId: string }
  | { type: "bookingFlow"; business: Business; service?: Service; staff?: StaffMember }
  | { type: "queueTracker"; bookingId: string; businessName: string; businessAddress?: string }
  | { type: "notifications" }
  | { type: "editProfile" }
  | { type: "addresses" }
  | { type: "favourites" }
  | { type: "login" }
  | null;

export function AppShell() {
  const { isLoggedIn } = useAuth();
  const [activeTab, setActiveTab] = useState<TabName>("home");
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState<Filters>(DEFAULT_FILTERS);
  const [exploreCategoryFilter, setExploreCategoryFilter] = useState<string | undefined>();
  const [modal, setModal] = useState<ModalType>(null);

  const { data: bookingsData } = useBookings("upcoming");
  const upcomingCount = isLoggedIn ? (bookingsData?.length ?? 0) : 0;

  const closeModal = useCallback(() => setModal(null), []);

  const openBusinessDetail = useCallback((businessId: string) => {
    setModal({ type: "businessDetail", businessId });
  }, []);

  const openBookingFlow = useCallback(
    (business: Business, service?: Service, staff?: StaffMember) => {
      if (!isLoggedIn) { setModal({ type: "login" }); return; }
      setModal({ type: "bookingFlow", business, service, staff });
    },
    [isLoggedIn],
  );

  const openQueueTracker = useCallback(
    (bookingId: string, businessName: string, businessAddress?: string) => {
      setModal({ type: "queueTracker", bookingId, businessName, businessAddress });
    },
    [],
  );

  const goToExplore = useCallback((category?: string) => {
    setExploreCategoryFilter(category);
    setActiveTab("explore");
    setModal(null);
  }, []);

  const goToBookings = useCallback(() => {
    setActiveTab("bookings");
    setModal(null);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="pb-24 animate-fade-up">
        {activeTab === "home" && (
          <HomeTab
            onGoExplore={goToExplore}
            searchQuery={searchQuery}
            onSearchChange={(q) => { setSearchQuery(q); if (q) { setActiveTab("explore"); } }}
            onViewBusiness={openBusinessDetail}
            onOpenNotifications={() => {
              if (!isLoggedIn) { setModal({ type: "login" }); return; }
              setModal({ type: "notifications" });
            }}
          />
        )}
        {activeTab === "explore" && (
          <ExploreTab
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            filters={filters}
            onFiltersChange={setFilters}
            initialCategory={exploreCategoryFilter}
            onViewBusiness={openBusinessDetail}
          />
        )}
        {activeTab === "bookings" && (
          <BookingsTab
            onGoHome={() => setActiveTab("home")}
            onViewQueue={openQueueTracker}
          />
        )}
        {activeTab === "profile" && (
          <ProfileTab
            onGoHome={() => setActiveTab("home")}
            onOpenNotifications={() => setModal({ type: "notifications" })}
            onEditProfile={() => setModal({ type: "editProfile" })}
            onOpenAddresses={() => setModal({ type: "addresses" })}
            onOpenFavourites={() => setModal({ type: "favourites" })}
            onOpenLogin={() => setModal({ type: "login" })}
          />
        )}
      </div>

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} bookingCount={upcomingCount} />

      {/* Modals */}
      {modal?.type === "login" && (
        <LoginScreen onBack={closeModal} onSuccess={closeModal} />
      )}
      {modal?.type === "businessDetail" && (
        <BusinessDetailSheet
          businessId={modal.businessId}
          onClose={closeModal}
          onBook={(business, service, staff) => { closeModal(); openBookingFlow(business, service, staff); }}
        />
      )}
      {modal?.type === "bookingFlow" && (
        <BookingFlowSheet
          business={modal.business}
          initialService={modal.service}
          initialStaff={modal.staff}
          onClose={closeModal}
          onSuccess={() => { closeModal(); goToBookings(); }}
        />
      )}
      {modal?.type === "queueTracker" && (
        <QueueTrackerSheet
          bookingId={modal.bookingId}
          businessName={modal.businessName}
          businessAddress={modal.businessAddress}
          onClose={closeModal}
        />
      )}
      {modal?.type === "notifications" && <NotificationsPanel onClose={closeModal} />}
      {modal?.type === "editProfile" && <EditProfileSheet onClose={closeModal} />}
      {modal?.type === "addresses" && <AddressesSheet onClose={closeModal} />}
      {modal?.type === "favourites" && (
        <FavouritesSheet
          onClose={closeModal}
          onViewBusiness={(id) => { closeModal(); openBusinessDetail(id); }}
        />
      )}
    </div>
  );
}
