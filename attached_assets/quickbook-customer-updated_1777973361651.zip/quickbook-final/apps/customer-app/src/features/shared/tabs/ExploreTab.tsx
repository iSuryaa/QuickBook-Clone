"use client";

import { useState, useMemo, useEffect } from "react";
import { SlidersHorizontal, Search } from "lucide-react";
import { SearchBar } from "@/components/ui/SearchBar";
import { BusinessCard } from "@/features/businesses/BusinessCard";
import { FilterSheet } from "@/features/businesses/FilterSheet";
import { BusinessCardSkeleton } from "@/components/ui/Skeleton";
import { EmptyState } from "@/components/ui/EmptyState";
import { useBusinesses } from "@/features/businesses/use-businesses";
import { useToggleFavorite, useFavorites } from "@/features/profile/use-profile";
import { applyFilters } from "@que/utils";
import { cn } from "@/lib/utils";
import type { Filters, CategoryId } from "@que/types";

const CATEGORY_TABS: { id: "all" | CategoryId; label: string }[] = [
  { id: "all", label: "All" },
  { id: "hospital", label: "Hospital" },
  { id: "salon", label: "Salon" },
  { id: "hotel", label: "Hotel" },
  { id: "gym", label: "Gym" },
  { id: "restaurant", label: "Restaurant" },
  { id: "entertainment", label: "Cinema" },
  { id: "games", label: "Games" },
];

interface ExploreTabProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  filters: Filters;
  onFiltersChange: (f: Filters) => void;
  initialCategory?: string;
  onViewBusiness: (id: string) => void;
}

export function ExploreTab({
  searchQuery, onSearchChange, filters, onFiltersChange, initialCategory, onViewBusiness,
}: ExploreTabProps) {
  const [activeCategory, setActiveCategory] = useState<"all" | CategoryId>(
    (initialCategory as CategoryId) ?? "all",
  );
  const [showFilters, setShowFilters] = useState(false);
  const { data: businesses, isLoading } = useBusinesses({
    category: activeCategory === "all" ? undefined : activeCategory,
  });
  const { data: favData } = useFavorites();
  const toggleFav = useToggleFavorite();

  useEffect(() => {
    if (initialCategory) setActiveCategory(initialCategory as CategoryId);
  }, [initialCategory]);

  const favoriteIds = useMemo(
    () => (favData as { business: { id: string } }[] | undefined)?.map((f) => f.business.id) ?? [],
    [favData],
  );

  const filtered = useMemo(() => {
    if (!businesses?.data) return [];
    return applyFilters(businesses.data, filters, searchQuery);
  }, [businesses?.data, filters, searchQuery]);

  const activeFilterCount =
    (filters.minRating > 0 ? 1 : 0) +
    (filters.maxDistanceKm < 10 ? 1 : 0) +
    (filters.openOnly ? 1 : 0) +
    (filters.priceLevels.length < 4 ? 1 : 0);

  return (
    <div className="pt-12 px-5">
      <h1 className="text-2xl font-bold mb-4">Explore</h1>

      {/* Search + filter */}
      <div className="flex gap-2 mb-4">
        <SearchBar value={searchQuery} onChange={onSearchChange} placeholder="Search by name or area" className="flex-1" />
        <button
          onClick={() => setShowFilters(true)}
          className={cn(
            "w-12 h-12 rounded-2xl border flex items-center justify-center shrink-0 relative",
            activeFilterCount > 0 ? "bg-indigo-500 text-white border-indigo-500" : "bg-white text-slate-600 border-slate-100",
          )}
        >
          <SlidersHorizontal size={18} />
          {activeFilterCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-white text-indigo-500 text-[9px] font-bold rounded-full flex items-center justify-center border border-indigo-200">
              {activeFilterCount}
            </span>
          )}
        </button>
      </div>

      {/* Category pills */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 mb-5">
        {CATEGORY_TABS.map(({ id, label }) => (
          <button
            key={id}
            onClick={() => setActiveCategory(id)}
            className={cn(
              "px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap border transition-colors",
              activeCategory === id ? "bg-indigo-500 text-white border-indigo-500" : "bg-white text-slate-600 border-slate-200",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {!isLoading && (
        <p className="text-xs text-slate-400 mb-3">
          {filtered.length} result{filtered.length !== 1 ? "s" : ""}
        </p>
      )}

      <div className="flex flex-col gap-4 pb-6">
        {isLoading
          ? Array.from({ length: 5 }).map((_, i) => <BusinessCardSkeleton key={i} />)
          : filtered.length === 0
            ? <EmptyState icon={Search} title="No results" description="Try adjusting your search or filters" />
            : filtered.map((business) => (
                <BusinessCard
                  key={business.id}
                  business={business}
                  isFavorite={favoriteIds.includes(business.id)}
                  onToggleFavorite={(id) => toggleFav.mutate(id)}
                  onClick={onViewBusiness}
                />
              ))}
      </div>

      {showFilters && (
        <FilterSheet filters={filters} onApply={onFiltersChange} onClose={() => setShowFilters(false)} />
      )}
    </div>
  );
}
