"use client";

import {
  User, Bell, MapPin, CreditCard, Heart, HelpCircle,
  Settings, LogOut, ChevronRight, Calendar,
} from "lucide-react";
import { useAuth } from "@/features/auth/use-auth";
import { useNotifications } from "@/features/profile/use-profile";
import { EmptyState } from "@/components/ui/EmptyState";

interface ProfileTabProps {
  onGoHome: () => void;
  onOpenNotifications: () => void;
  onEditProfile: () => void;
  onOpenAddresses: () => void;
  onOpenFavourites: () => void;
  onOpenLogin: () => void;
}

export function ProfileTab({
  onGoHome,
  onOpenNotifications,
  onEditProfile,
  onOpenAddresses,
  onOpenFavourites,
  onOpenLogin,
}: ProfileTabProps) {
  const { user, isLoggedIn, logout } = useAuth();
  const { data: notifs } = useNotifications();
  const unreadCount = notifs?.filter((n) => !n.read).length ?? 0;

  if (!isLoggedIn) {
    return (
      <div className="pt-12 px-5">
        <h1 className="text-2xl font-bold mb-6">Profile</h1>
        <EmptyState
          icon={User}
          title="Sign in to view your profile"
          description="Manage your bookings, addresses, and saved cards."
          action={{ label: "Sign in", onClick: onOpenLogin }}
        />
      </div>
    );
  }

  return (
    <div className="pt-12 px-5 pb-8">
      {/* Avatar + name */}
      <div className="flex items-center gap-4 mb-8">
        <div className="w-16 h-16 rounded-2xl bg-indigo-100 flex items-center justify-center">
          <span className="text-2xl font-bold text-indigo-500">
            {user?.name.charAt(0).toUpperCase()}
          </span>
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-lg truncate">{user?.name}</p>
          <p className="text-sm text-slate-500">{user?.phone}</p>
          {user?.email && <p className="text-xs text-slate-400 truncate">{user.email}</p>}
        </div>
        <button
          onClick={onEditProfile}
          className="text-xs font-bold text-indigo-500 bg-indigo-50 px-3 py-1.5 rounded-full"
        >
          Edit
        </button>
      </div>

      {/* Menu groups */}
      <MenuGroup label="Account">
        <MenuItem icon={User} label="Edit profile" onClick={onEditProfile} />
        <MenuItem icon={Bell} label="Notifications" badge={unreadCount} onClick={onOpenNotifications} />
        <MenuItem icon={MapPin} label="Saved addresses" onClick={onOpenAddresses} />
        <MenuItem icon={CreditCard} label="Payment methods" onClick={() => {}} />
        <MenuItem icon={Heart} label="Favourites" onClick={onOpenFavourites} />
      </MenuGroup>

      <MenuGroup label="Activity">
        <MenuItem icon={Calendar} label="Booking history" onClick={() => {}} />
      </MenuGroup>

      <MenuGroup label="Support">
        <MenuItem icon={HelpCircle} label="Help & FAQ" onClick={() => {}} />
        <MenuItem icon={Settings} label="Settings" onClick={() => {}} />
      </MenuGroup>

      {/* Sign out */}
      <button
        onClick={logout}
        className="w-full mt-4 flex items-center gap-3 px-4 py-4 text-red-500 font-semibold text-sm"
      >
        <LogOut size={18} />
        Sign out
      </button>

      <p className="text-center text-xs text-slate-300 mt-4">Que Booking v1.0.0</p>
    </div>
  );
}

function MenuGroup({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-5">
      <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 px-1">{label}</p>
      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden divide-y divide-slate-50">
        {children}
      </div>
    </div>
  );
}

function MenuItem({
  icon: Icon, label, badge, onClick,
}: {
  icon: typeof User; label: string; badge?: number; onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-3 px-4 py-4 text-left hover:bg-slate-50 transition-colors"
    >
      <Icon size={18} className="text-slate-400 shrink-0" />
      <span className="flex-1 text-sm font-medium">{label}</span>
      {badge != null && badge > 0 && (
        <span className="w-5 h-5 bg-indigo-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
          {badge > 9 ? "9+" : badge}
        </span>
      )}
      <ChevronRight size={16} className="text-slate-300" />
    </button>
  );
}
