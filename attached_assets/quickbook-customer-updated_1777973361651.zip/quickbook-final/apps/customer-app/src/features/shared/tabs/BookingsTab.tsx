"use client";

import { useState } from "react";
import { Calendar } from "lucide-react";
import { BookingCard } from "@/features/bookings/BookingCard";
import { BookingDetailSheet } from "@/features/bookings/BookingDetailSheet";
import { BookingCardSkeleton } from "@/components/ui/Skeleton";
import { EmptyState } from "@/components/ui/EmptyState";
import { useBookings, useCancelBooking } from "@/features/bookings/use-bookings";
import { useBusinesses } from "@/features/businesses/use-businesses";
import { useAuth } from "@/features/auth/use-auth";
import { useToast } from "@/components/ui/Toast";
import { cn } from "@/lib/utils";
import type { BookingStatus } from "@que/types";

type TabFilter = "all" | BookingStatus;

const TABS: { id: TabFilter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "upcoming", label: "Upcoming" },
  { id: "in-queue", label: "In Queue" },
  { id: "completed", label: "Completed" },
  { id: "cancelled", label: "Cancelled" },
];

interface BookingsTabProps {
  onGoHome: () => void;
  onViewQueue: (bookingId: string, businessName: string, businessAddress?: string) => void;
}

export function BookingsTab({ onGoHome, onViewQueue }: BookingsTabProps) {
  const { isLoggedIn } = useAuth();
  const [activeFilter, setActiveFilter] = useState<TabFilter>("all");
  const [detailBooking, setDetailBooking] = useState<{ id: string; bizName: string; bizAddress?: string } | null>(null);
  const { data: bookings, isLoading } = useBookings(activeFilter === "all" ? undefined : activeFilter);
  const { data: allBusinesses } = useBusinesses({ pageSize: 100 });
  const cancelBooking = useCancelBooking();
  const { toast } = useToast();

  const businessMap = new Map(
    (allBusinesses?.data ?? []).map((b) => [b.id, { name: b.name, address: b.address }]),
  );

  if (!isLoggedIn) {
    return (
      <div className="pt-12 px-5">
        <h1 className="text-2xl font-bold mb-6">My Bookings</h1>
        <EmptyState
          icon={Calendar}
          title="Sign in to view bookings"
          description="Your bookings will appear here once you're signed in."
          action={{ label: "Sign in", onClick: onGoHome }}
        />
      </div>
    );
  }

  const handleCancel = (id: string) => {
    cancelBooking.mutate(id, {
      onSuccess: () => toast("Booking cancelled", "success"),
      onError: (err) => toast(err.message, "error"),
    });
  };

  return (
    <div className="pt-12 px-5">
      <h1 className="text-2xl font-bold mb-4">My Bookings</h1>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 mb-5">
        {TABS.map(({ id, label }) => (
          <button
            key={id}
            onClick={() => setActiveFilter(id)}
            className={cn(
              "px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap border transition-colors",
              activeFilter === id
                ? "bg-indigo-500 text-white border-indigo-500"
                : "bg-white text-slate-600 border-slate-200",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-4 pb-6">
        {isLoading ? (
          Array.from({ length: 3 }).map((_, i) => <BookingCardSkeleton key={i} />)
        ) : !bookings?.length ? (
          <EmptyState
            icon={Calendar}
            title="No bookings yet"
            description="Your appointments will appear here."
            action={{ label: "Explore businesses", onClick: onGoHome }}
          />
        ) : (
          bookings.map((booking) => {
            const biz = businessMap.get(booking.businessId);
            const bizName = biz?.name ?? booking.businessId;
            const bizAddress = biz?.address;
            return (
              <BookingCard
                key={booking.id}
                booking={booking}
                businessName={bizName}
                serviceName={booking.serviceId}
                onViewDetails={() => setDetailBooking({ id: booking.id, bizName, bizAddress })}
                onCancel={handleCancel}
                onViewQueue={() => onViewQueue(booking.id, bizName, bizAddress)}
              />
            );
          })
        )}
      </div>

      {/* Booking detail modal */}
      {detailBooking && (
        <BookingDetailSheet
          bookingId={detailBooking.id}
          businessName={detailBooking.bizName}
          businessAddress={detailBooking.bizAddress}
          onClose={() => setDetailBooking(null)}
          onViewQueue={() => {
            const b = bookings?.find((bk) => bk.id === detailBooking.id);
            if (b) {
              setDetailBooking(null);
              onViewQueue(b.id, detailBooking.bizName, detailBooking.bizAddress);
            }
          }}
        />
      )}
    </div>
  );
}
