"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { bookingsService } from "./bookings.service";
import { useAuth } from "@/features/auth/use-auth";
import type { CreateBookingInput } from "@que/shared";

export const bookingKeys = {
  all: ["bookings"] as const,
  list: (status?: string) => [...bookingKeys.all, "list", status] as const,
  detail: (id: string) => [...bookingKeys.all, "detail", id] as const,
  queue: (id: string) => [...bookingKeys.all, "queue", id] as const,
};

export function useBookings(status?: string) {
  const { token } = useAuth();
  return useQuery({
    queryKey: bookingKeys.list(status),
    queryFn: () => bookingsService.list(token!, status),
    enabled: Boolean(token),
    staleTime: 1000 * 30,
  });
}

export function useBooking(id: string) {
  const { token } = useAuth();
  return useQuery({
    queryKey: bookingKeys.detail(id),
    queryFn: () => bookingsService.getById(id, token!),
    enabled: Boolean(token && id),
  });
}

export function useQueuePosition(bookingId: string) {
  const { token } = useAuth();
  return useQuery({
    queryKey: bookingKeys.queue(bookingId),
    queryFn: () => bookingsService.getQueuePosition(bookingId, token!),
    enabled: Boolean(token && bookingId),
    refetchInterval: 30_000, // live poll every 30 s
    staleTime: 0,
  });
}

export function useCreateBooking() {
  const { token } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateBookingInput) => bookingsService.create(data, token!),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: bookingKeys.all });
    },
  });
}

export function useCancelBooking() {
  const { token } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => bookingsService.cancel(id, token!),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: bookingKeys.all });
    },
  });
}
