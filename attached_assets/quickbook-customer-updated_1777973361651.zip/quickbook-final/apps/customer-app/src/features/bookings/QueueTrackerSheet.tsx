"use client";

import { useEffect, useState } from "react";
import {
  X, CheckCircle2, Clock, Users, MapPin,
  Navigation, QrCode, Phone, AlertCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useQueuePosition, useCancelBooking } from "./use-bookings";
import { useToast } from "@/components/ui/Toast";
import { Skeleton } from "@/components/ui/Skeleton";

interface QueueTrackerSheetProps {
  bookingId: string;
  businessName: string;
  businessAddress?: string;
  onClose: () => void;
}

export function QueueTrackerSheet({
  bookingId,
  businessName,
  businessAddress,
  onClose,
}: QueueTrackerSheetProps) {
  const { data, isLoading, dataUpdatedAt } = useQueuePosition(bookingId);
  const cancelBooking = useCancelBooking();
  const { toast } = useToast();
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);

  useEffect(() => {
    if (dataUpdatedAt) setLastUpdated(new Date(dataUpdatedAt));
  }, [dataUpdatedAt]);

  const position = data?.position ?? null;
  const booking = data?.booking;

  const handleCancel = () => {
    cancelBooking.mutate(bookingId, {
      onSuccess: () => {
        toast("Booking cancelled", "success");
        onClose();
      },
      onError: (err) => toast(err.message, "error"),
    });
  };

  // Estimate wait: 15 min per person ahead
  const estimatedWait = position != null ? Math.max(0, (position - 1) * 15) : null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60">
      <div
        className="bg-slate-50 w-full max-w-[480px] rounded-t-3xl max-h-[90vh] flex flex-col animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center gap-3 px-5 pt-5 pb-4 bg-white rounded-t-3xl border-b border-slate-100 shrink-0">
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center"
          >
            <X size={18} />
          </button>
          <div className="flex-1">
            <h2 className="font-bold text-base">Live Queue</h2>
            <p className="text-xs text-slate-400">{businessName}</p>
          </div>
          {/* Live pulse indicator */}
          <div className="flex items-center gap-1.5">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
            </span>
            <span className="text-xs font-semibold text-emerald-600">Live</span>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-5 py-5 flex flex-col gap-5 pb-28">

          {/* Big position counter */}
          <div className={cn(
            "rounded-3xl p-6 text-center",
            position === 1
              ? "bg-emerald-500"
              : position != null && position <= 3
                ? "bg-amber-400"
                : "bg-indigo-500",
          )}>
            {isLoading ? (
              <div className="flex flex-col items-center gap-2">
                <Skeleton className="h-16 w-24 rounded-2xl mx-auto bg-white/20" />
                <Skeleton className="h-4 w-32 rounded-full mx-auto bg-white/20" />
              </div>
            ) : position === null ? (
              <div className="flex flex-col items-center gap-2">
                <CheckCircle2 size={48} className="text-white" />
                <p className="text-white font-bold text-lg">It's your turn!</p>
                <p className="text-white/80 text-sm">Head over to the counter now</p>
              </div>
            ) : (
              <>
                <p className="text-white/80 text-sm font-medium mb-1">Your position</p>
                <p className="text-white font-black text-7xl leading-none tabular-nums">
                  #{position}
                </p>
                {estimatedWait != null && estimatedWait > 0 && (
                  <div className="mt-3 inline-flex items-center gap-1.5 bg-white/20 rounded-full px-4 py-1.5">
                    <Clock size={13} className="text-white" />
                    <span className="text-white text-sm font-semibold">
                      ~{estimatedWait} min wait
                    </span>
                  </div>
                )}
                {position === 1 && (
                  <p className="text-white/90 mt-2 text-sm font-medium">Almost your turn — head over!</p>
                )}
              </>
            )}
          </div>

          {/* Token + Business info */}
          {booking && (
            <div className="bg-white rounded-2xl border border-slate-100 px-4 py-4 flex flex-col gap-3">
              {booking.token && (
                <div className="flex items-center justify-between pb-3 border-b border-slate-50">
                  <div className="flex items-center gap-2 text-slate-500">
                    <QrCode size={15} className="text-indigo-400" />
                    <span className="text-xs font-medium">Your token</span>
                  </div>
                  <span className="font-mono font-black text-lg text-indigo-500 tracking-wider">
                    {booking.token}
                  </span>
                </div>
              )}
              {businessAddress && (
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <MapPin size={13} className="text-indigo-400 shrink-0" />
                  <span>{businessAddress}</span>
                </div>
              )}
              {booking.date && booking.time && (
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <Clock size={13} className="text-indigo-400 shrink-0" />
                  <span>{booking.date} at {booking.time}</span>
                </div>
              )}
              {booking.persons > 1 && (
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <Users size={13} className="text-indigo-400 shrink-0" />
                  <span>{booking.persons} people</span>
                </div>
              )}
            </div>
          )}

          {/* Progress timeline */}
          {!isLoading && position != null && (
            <div className="bg-white rounded-2xl border border-slate-100 px-4 py-4">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-4">Progress</p>
              <div className="flex flex-col gap-0">
                {[
                  {
                    label: "Booking confirmed",
                    desc: "Slot secured",
                    done: true,
                    active: false,
                  },
                  {
                    label: "In queue",
                    desc: position > 1 ? `${position - 1} people ahead of you` : "You're next!",
                    done: false,
                    active: true,
                  },
                  {
                    label: "Your turn",
                    desc: estimatedWait != null ? `~${estimatedWait} min away` : "Coming up",
                    done: false,
                    active: false,
                  },
                  {
                    label: "Serving",
                    desc: "Enjoy your appointment!",
                    done: false,
                    active: false,
                  },
                ].map((step, i, arr) => (
                  <div key={step.label} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className={cn(
                        "w-7 h-7 rounded-full flex items-center justify-center shrink-0 z-10",
                        step.done
                          ? "bg-emerald-500"
                          : step.active
                            ? "bg-indigo-500 ring-4 ring-indigo-100"
                            : "bg-slate-200",
                      )}>
                        {step.done ? (
                          <CheckCircle2 size={14} className="text-white" />
                        ) : (
                          <span className={cn("text-xs font-bold", step.active ? "text-white" : "text-slate-400")}>
                            {i + 1}
                          </span>
                        )}
                      </div>
                      {i < arr.length - 1 && (
                        <div className={cn(
                          "w-0.5 h-8 -mt-0.5",
                          step.done ? "bg-emerald-300" : "bg-slate-200",
                        )} />
                      )}
                    </div>
                    <div className="pb-6 pt-0.5">
                      <p className={cn(
                        "text-sm font-semibold leading-tight",
                        step.active ? "text-indigo-600" : step.done ? "text-slate-700" : "text-slate-400",
                      )}>
                        {step.label}
                      </p>
                      <p className="text-xs text-slate-400 mt-0.5">{step.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Last updated */}
          {lastUpdated && (
            <p className="text-center text-[10px] text-slate-300">
              Updated {lastUpdated.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })} · refreshes every 30s
            </p>
          )}

          {/* Cancel confirm */}
          {showCancelConfirm && (
            <div className="bg-red-50 border border-red-100 rounded-2xl px-4 py-4 flex flex-col gap-3">
              <div className="flex items-start gap-2.5">
                <AlertCircle size={16} className="text-red-500 shrink-0 mt-0.5" />
                <p className="text-sm text-red-700 font-medium">
                  Cancel your booking? This cannot be undone.
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowCancelConfirm(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600"
                >
                  Keep it
                </button>
                <button
                  onClick={handleCancel}
                  disabled={cancelBooking.isPending}
                  className="flex-1 py-2.5 rounded-xl bg-red-500 text-white text-sm font-semibold disabled:opacity-60"
                >
                  {cancelBooking.isPending ? "Cancelling…" : "Yes, cancel"}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="shrink-0 bg-white border-t border-slate-100 px-5 py-4 flex gap-3">
          {!showCancelConfirm && (
            <button
              onClick={() => setShowCancelConfirm(true)}
              className="flex-1 py-3.5 rounded-2xl border-2 border-red-100 text-red-500 font-bold text-sm"
            >
              Cancel booking
            </button>
          )}
          <button
            onClick={onClose}
            className="flex-1 py-3.5 rounded-2xl bg-indigo-500 text-white font-bold text-sm"
          >
            {position === null ? "Done" : "Got it"}
          </button>
        </div>
      </div>
    </div>
  );
}
