import { apiClient } from "@/lib/api-client";
import type { Booking } from "@que/types";
import type { CreateBookingInput } from "@que/shared";

export const bookingsService = {
  list: (token: string, status?: string) => {
    const qs = status ? `?status=${status}` : "";
    return apiClient.get<Booking[]>(`/bookings${qs}`, token);
  },

  getById: (id: string, token: string) =>
    apiClient.get<Booking>(`/bookings/${id}`, token),

  create: (data: CreateBookingInput, token: string) =>
    apiClient.post<Booking>("/bookings", data, token),

  cancel: (id: string, token: string) =>
    apiClient.post<Booking>(`/bookings/${id}/cancel`, {}, token),

  getQueuePosition: (id: string, token: string) =>
    apiClient.get<{ position: number | null; booking: Booking }>(`/bookings/${id}/queue`, token),
};
