"use client";

import { useState, useMemo } from "react";
import {
  X, ChevronLeft, Calendar, Clock, Users, CreditCard,
  CheckCircle2, ChevronRight, Minus, Plus, AlertCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { formatINR, formatDuration, generateTimeSlots, generateBookingToken } from "@que/utils";
import { useCreateBooking } from "./use-bookings";
import { useToast } from "@/components/ui/Toast";
import type { Business, Service, StaffMember } from "@que/types";

interface BookingFlowSheetProps {
  business: Business;
  initialService?: Service;
  initialStaff?: StaffMember;
  onClose: () => void;
  onSuccess: (bookingId: string) => void;
}

type Step = "datetime" | "persons" | "confirm" | "success";

const DAYS_AHEAD = 14;

function getDateOptions() {
  const opts: { label: string; iso: string; short: string }[] = [];
  const now = new Date();
  for (let i = 0; i < DAYS_AHEAD; i++) {
    const d = new Date(now);
    d.setDate(now.getDate() + i);
    const iso = d.toISOString().slice(0, 10);
    const short = d.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" });
    const label = i === 0 ? "Today" : i === 1 ? "Tomorrow" : short;
    opts.push({ label, iso, short });
  }
  return opts;
}

export function BookingFlowSheet({
  business,
  initialService,
  initialStaff,
  onClose,
  onSuccess,
}: BookingFlowSheetProps) {
  const [step, setStep] = useState<Step>("datetime");
  const [selectedService, setSelectedService] = useState<Service | null>(initialService ?? null);
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(initialStaff ?? null);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedTime, setSelectedTime] = useState<string>("");
  const [persons, setPersons] = useState(1);
  const [confirmedToken, setConfirmedToken] = useState("");

  const createBooking = useCreateBooking();
  const { toast } = useToast();
  const dates = useMemo(() => getDateOptions(), []);
  const timeSlots = useMemo(() => generateTimeSlots(9, 21, 30), []);

  const bookingFee = 1500; // ₹15 in paise
  const servicePrice = selectedService?.price ?? 0;

  const canProceedFromDateTime = selectedDate && selectedTime;
  const canProceedFromPersons = persons >= 1;

  function handleConfirm() {
    if (!selectedDate || !selectedTime) return;

    createBooking.mutate(
      {
        businessId: business.id,
        serviceId: selectedService?.id ?? (business.services?.[0]?.id ?? ""),
        staffId: selectedStaff?.id ?? null,
        date: selectedDate,
        time: selectedTime,
        persons,
        isWalkIn: false,
      },
      {
        onSuccess: (data) => {
          setConfirmedToken(data.token ?? generateBookingToken());
          setStep("success");
        },
        onError: (err) => {
          toast(err.message ?? "Booking failed. Try again.", "error");
        },
      },
    );
  }

  const stepTitles: Record<Step, string> = {
    datetime: "Pick date & time",
    persons: "Party size",
    confirm: "Review & confirm",
    success: "Confirmed!",
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50">
      <div
        className="bg-slate-50 w-full max-w-[480px] rounded-t-3xl max-h-[92vh] flex flex-col animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        {step !== "success" && (
          <div className="flex items-center gap-3 px-5 pt-5 pb-4 bg-white rounded-t-3xl border-b border-slate-100 shrink-0">
            <button
              onClick={step === "datetime" ? onClose : () => {
                if (step === "persons") setStep("datetime");
                else if (step === "confirm") setStep("persons");
              }}
              className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center shrink-0"
            >
              {step === "datetime" ? <X size={18} /> : <ChevronLeft size={18} />}
            </button>
            <div className="flex-1">
              <p className="text-xs text-slate-400">{business.name}</p>
              <h2 className="font-bold text-base leading-tight">{stepTitles[step]}</h2>
            </div>
            {/* Step dots */}
            <div className="flex gap-1.5">
              {(["datetime", "persons", "confirm"] as Step[]).map((s, i) => {
                const steps: Step[] = ["datetime", "persons", "confirm"];
                const currentIdx = steps.indexOf(step);
                const dotIdx = i;
                return (
                  <div
                    key={s}
                    className={cn(
                      "h-1.5 rounded-full transition-all",
                      dotIdx <= currentIdx ? "bg-indigo-500 w-4" : "bg-slate-200 w-1.5",
                    )}
                  />
                );
              })}
            </div>
          </div>
        )}

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto">
          {/* ── STEP 1: Date & Time ── */}
          {step === "datetime" && (
            <div className="px-5 py-5 flex flex-col gap-6 pb-32">
              {/* Service picker (if no service pre-selected and business has services) */}
              {!initialService && business.services?.length > 0 && (
                <section>
                  <SectionLabel>Service</SectionLabel>
                  <div className="flex flex-col gap-2">
                    {business.services.map((svc) => (
                      <button
                        key={svc.id}
                        onClick={() => setSelectedService(selectedService?.id === svc.id ? null : svc)}
                        className={cn(
                          "flex items-center justify-between p-4 bg-white rounded-2xl border text-left transition-all",
                          selectedService?.id === svc.id
                            ? "border-indigo-400 shadow-sm shadow-indigo-100"
                            : "border-slate-100",
                        )}
                      >
                        <div>
                          <p className="text-sm font-semibold">{svc.name}</p>
                          <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1">
                            <Clock size={10} /> {formatDuration(svc.duration)}
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-sm font-bold">{formatINR(svc.price / 100)}</span>
                          <div className={cn(
                            "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                            selectedService?.id === svc.id ? "border-indigo-500 bg-indigo-500" : "border-slate-300",
                          )}>
                            {selectedService?.id === svc.id && <CheckCircle2 size={12} className="text-white" />}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </section>
              )}

              {/* Date picker */}
              <section>
                <SectionLabel>Date</SectionLabel>
                <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                  {dates.map(({ label, iso }) => (
                    <button
                      key={iso}
                      onClick={() => setSelectedDate(iso)}
                      className={cn(
                        "flex flex-col items-center gap-0.5 px-3 py-2.5 rounded-2xl border shrink-0 min-w-[60px] transition-all",
                        selectedDate === iso
                          ? "bg-indigo-500 border-indigo-500 text-white"
                          : "bg-white border-slate-100 text-slate-700",
                      )}
                    >
                      <span className={cn("text-[10px] font-medium", selectedDate === iso ? "text-indigo-200" : "text-slate-400")}>
                        {label.length > 7 ? label.split(",")[0] : label}
                      </span>
                      <span className="text-base font-bold leading-none">
                        {new Date(iso + "T00:00:00").getDate()}
                      </span>
                      <span className={cn("text-[9px]", selectedDate === iso ? "text-indigo-200" : "text-slate-400")}>
                        {new Date(iso + "T00:00:00").toLocaleDateString("en-IN", { month: "short" })}
                      </span>
                    </button>
                  ))}
                </div>
              </section>

              {/* Time slots */}
              {selectedDate && (
                <section>
                  <SectionLabel>Time</SectionLabel>
                  <div className="grid grid-cols-3 gap-2">
                    {timeSlots.map((slot) => (
                      <button
                        key={slot}
                        onClick={() => setSelectedTime(slot)}
                        className={cn(
                          "py-2.5 rounded-xl border text-xs font-semibold transition-all",
                          selectedTime === slot
                            ? "bg-indigo-500 border-indigo-500 text-white"
                            : "bg-white border-slate-100 text-slate-700",
                        )}
                      >
                        {slot}
                      </button>
                    ))}
                  </div>
                </section>
              )}
            </div>
          )}

          {/* ── STEP 2: Persons ── */}
          {step === "persons" && (
            <div className="px-5 py-6 flex flex-col gap-6 pb-32">
              {/* Person counter */}
              <section>
                <SectionLabel>How many people?</SectionLabel>
                <div className="bg-white rounded-2xl border border-slate-100 p-6 flex items-center justify-between">
                  <button
                    onClick={() => setPersons((p) => Math.max(1, p - 1))}
                    className="w-11 h-11 rounded-full border-2 border-slate-200 flex items-center justify-center text-slate-600 active:scale-95 transition-transform"
                  >
                    <Minus size={18} />
                  </button>
                  <div className="text-center">
                    <span className="text-5xl font-bold text-slate-800 tabular-nums">{persons}</span>
                    <p className="text-xs text-slate-400 mt-1">{persons === 1 ? "person" : "people"}</p>
                  </div>
                  <button
                    onClick={() => setPersons((p) => Math.min(20, p + 1))}
                    className="w-11 h-11 rounded-full border-2 border-slate-200 flex items-center justify-center text-slate-600 active:scale-95 transition-transform"
                  >
                    <Plus size={18} />
                  </button>
                </div>
              </section>

              {/* Selected service summary */}
              {selectedService && (
                <section>
                  <SectionLabel>Service selected</SectionLabel>
                  <div className="bg-white rounded-2xl border border-slate-100 p-4 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-sm">{selectedService.name}</p>
                      <p className="text-xs text-slate-400 mt-0.5">{formatDuration(selectedService.duration)}</p>
                    </div>
                    <span className="font-bold text-sm">{formatINR(selectedService.price / 100)}</span>
                  </div>
                </section>
              )}

              {/* Staff if selected */}
              {selectedStaff && (
                <section>
                  <SectionLabel>Staff</SectionLabel>
                  <div className="bg-white rounded-2xl border border-slate-100 p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center">
                      <span className="font-bold text-indigo-500">{selectedStaff.name.charAt(0)}</span>
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{selectedStaff.name}</p>
                      <p className="text-xs text-slate-400">{selectedStaff.role}</p>
                    </div>
                  </div>
                </section>
              )}

              {/* Date/time summary */}
              <section>
                <SectionLabel>Schedule</SectionLabel>
                <div className="bg-white rounded-2xl border border-slate-100 p-4 flex gap-4">
                  <div className="flex items-center gap-2 flex-1">
                    <Calendar size={15} className="text-indigo-400 shrink-0" />
                    <span className="text-sm font-medium">
                      {new Date(selectedDate + "T00:00:00").toLocaleDateString("en-IN", {
                        weekday: "short", day: "numeric", month: "short",
                      })}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 flex-1">
                    <Clock size={15} className="text-indigo-400 shrink-0" />
                    <span className="text-sm font-medium">{selectedTime}</span>
                  </div>
                </div>
              </section>
            </div>
          )}

          {/* ── STEP 3: Confirm ── */}
          {step === "confirm" && (
            <div className="px-5 py-5 flex flex-col gap-4 pb-32">
              {/* Booking summary card */}
              <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
                <div className="px-4 pt-4 pb-3 border-b border-slate-50">
                  <p className="font-bold text-sm">{business.name}</p>
                  <p className="text-xs text-slate-400 mt-0.5">{business.address}</p>
                </div>

                <div className="px-4 py-3 flex flex-col gap-3">
                  <SummaryRow
                    icon={<Calendar size={14} className="text-indigo-400" />}
                    label="Date"
                    value={new Date(selectedDate + "T00:00:00").toLocaleDateString("en-IN", {
                      weekday: "long", day: "numeric", month: "long",
                    })}
                  />
                  <SummaryRow
                    icon={<Clock size={14} className="text-indigo-400" />}
                    label="Time"
                    value={selectedTime}
                  />
                  <SummaryRow
                    icon={<Users size={14} className="text-indigo-400" />}
                    label="People"
                    value={`${persons} ${persons === 1 ? "person" : "people"}`}
                  />
                  {selectedService && (
                    <SummaryRow
                      icon={<CheckCircle2 size={14} className="text-indigo-400" />}
                      label="Service"
                      value={selectedService.name}
                    />
                  )}
                  {selectedStaff && (
                    <SummaryRow
                      icon={<Users size={14} className="text-indigo-400" />}
                      label="Staff"
                      value={selectedStaff.name}
                    />
                  )}
                </div>
              </div>

              {/* Price breakdown */}
              <div className="bg-white rounded-2xl border border-slate-100 px-4 py-3 flex flex-col gap-2">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">Price breakdown</p>
                {servicePrice > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Service fee</span>
                    <span className="font-medium">{formatINR(servicePrice / 100)}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Booking convenience fee</span>
                  <span className="font-medium">{formatINR(bookingFee / 100)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">GST (18%)</span>
                  <span className="font-medium">
                    {formatINR(Math.round((servicePrice + bookingFee) * 0.18) / 100)}
                  </span>
                </div>
                <div className="border-t border-slate-100 pt-2 mt-1 flex justify-between">
                  <span className="font-bold text-sm">Total</span>
                  <span className="font-bold text-indigo-500">
                    {formatINR(Math.round((servicePrice + bookingFee) * 1.18) / 100)}
                  </span>
                </div>
              </div>

              {/* Payment method */}
              <div className="bg-white rounded-2xl border border-slate-100 px-4 py-3 flex items-center gap-3">
                <CreditCard size={18} className="text-indigo-400 shrink-0" />
                <span className="text-sm font-medium flex-1">Pay at venue</span>
                <ChevronRight size={16} className="text-slate-300" />
              </div>

              {/* Policy note */}
              <div className="flex items-start gap-2.5 bg-amber-50 border border-amber-100 rounded-2xl px-4 py-3">
                <AlertCircle size={15} className="text-amber-500 shrink-0 mt-0.5" />
                <p className="text-xs text-amber-700 leading-relaxed">
                  Free cancellation up to 1 hour before your appointment. The booking fee is non-refundable after that.
                </p>
              </div>
            </div>
          )}

          {/* ── STEP 4: Success ── */}
          {step === "success" && (
            <div className="flex flex-col items-center justify-center px-6 py-12 text-center gap-5">
              <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center">
                <CheckCircle2 size={40} className="text-emerald-500" />
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-1">You're booked!</h2>
                <p className="text-slate-500 text-sm">Your appointment is confirmed.</p>
              </div>

              <div className="w-full bg-white rounded-2xl border border-slate-100 p-5 text-left flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <p className="font-bold text-sm">{business.name}</p>
                  <span className="text-xs font-mono font-bold bg-indigo-50 text-indigo-500 px-3 py-1 rounded-full">
                    {confirmedToken}
                  </span>
                </div>
                <div className="border-t border-slate-50 pt-3 flex flex-col gap-2">
                  <SummaryRow
                    icon={<Calendar size={14} className="text-indigo-400" />}
                    label="Date"
                    value={new Date(selectedDate + "T00:00:00").toLocaleDateString("en-IN", {
                      weekday: "short", day: "numeric", month: "short",
                    })}
                  />
                  <SummaryRow
                    icon={<Clock size={14} className="text-indigo-400" />}
                    label="Time"
                    value={selectedTime}
                  />
                  <SummaryRow
                    icon={<Users size={14} className="text-indigo-400" />}
                    label="People"
                    value={`${persons}`}
                  />
                </div>
              </div>

              <div className="w-full flex flex-col gap-3">
                <button
                  onClick={() => onSuccess(confirmedToken)}
                  className="w-full py-3.5 rounded-2xl bg-indigo-500 text-white font-bold text-sm"
                >
                  View my bookings
                </button>
                <button
                  onClick={onClose}
                  className="w-full py-3 rounded-2xl border border-slate-200 text-slate-600 font-semibold text-sm"
                >
                  Back to explore
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer CTA */}
        {step !== "success" && (
          <div className="shrink-0 bg-white border-t border-slate-100 px-5 py-4 pb-safe">
            <button
              onClick={() => {
                if (step === "datetime") setStep("persons");
                else if (step === "persons") setStep("confirm");
                else if (step === "confirm") handleConfirm();
              }}
              disabled={
                (step === "datetime" && !canProceedFromDateTime) ||
                createBooking.isPending
              }
              className="w-full py-3.5 rounded-2xl bg-indigo-500 text-white font-bold text-sm disabled:opacity-50 active:scale-[0.98] transition-all"
            >
              {createBooking.isPending
                ? "Confirming…"
                : step === "confirm"
                  ? "Confirm booking"
                  : "Continue"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-2.5">{children}</p>
  );
}

function SummaryRow({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center gap-2.5">
      {icon}
      <span className="text-xs text-slate-400 w-14 shrink-0">{label}</span>
      <span className="text-xs font-semibold text-slate-700 flex-1">{value}</span>
    </div>
  );
}
