"use client";

import { X, Calendar, Clock, Users, QrCode, MapPin, CheckCircle2, XCircle, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatINR, canCancelBooking } from "@que/utils";
import { useBooking, useCancelBooking } from "./use-bookings";
import { useToast } from "@/components/ui/Toast";
import { Skeleton } from "@/components/ui/Skeleton";
import { useState } from "react";
import type { Booking } from "@que/types";

interface BookingDetailSheetProps {
  bookingId: string;
  businessName: string;
  businessAddress?: string;
  onClose: () => void;
  onViewQueue?: () => void;
}

const STATUS_CONFIG: Record<Booking["status"], { label: string; icon: typeof CheckCircle2; color: string; bg: string }> = {
  upcoming: { label: "Upcoming", icon: Clock, color: "text-indigo-600", bg: "bg-indigo-50" },
  "in-queue": { label: "In Queue", icon: AlertCircle, color: "text-amber-600", bg: "bg-amber-50" },
  completed: { label: "Completed", icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-50" },
  cancelled: { label: "Cancelled", icon: XCircle, color: "text-slate-400", bg: "bg-slate-100" },
};

export function BookingDetailSheet({
  bookingId,
  businessName,
  businessAddress,
  onClose,
  onViewQueue,
}: BookingDetailSheetProps) {
  const { data: booking, isLoading } = useBooking(bookingId);
  const cancelBooking = useCancelBooking();
  const { toast } = useToast();
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);

  const statusCfg = booking ? STATUS_CONFIG[booking.status] : null;
  const cancellable = booking ? canCancelBooking(booking) && booking.status === "upcoming" : false;

  const handleCancel = () => {
    cancelBooking.mutate(bookingId, {
      onSuccess: () => { toast("Booking cancelled", "success"); onClose(); },
      onError: (err) => toast(err.message, "error"),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50">
      <div className="bg-slate-50 w-full max-w-[480px] rounded-t-3xl max-h-[88vh] flex flex-col animate-slide-up" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center gap-3 px-5 pt-5 pb-4 bg-white rounded-t-3xl border-b border-slate-100 shrink-0">
          <button onClick={onClose} className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center"><X size={18} /></button>
          <div className="flex-1">
            <h2 className="font-bold text-base">Booking details</h2>
            <p className="text-xs text-slate-400">{businessName}</p>
          </div>
          {statusCfg && (
            <span className={cn("text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1", statusCfg.bg, statusCfg.color)}>
              <statusCfg.icon size={11} /> {statusCfg.label}
            </span>
          )}
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-5 flex flex-col gap-4 pb-28">
          {isLoading ? (
            Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-2xl" />)
          ) : booking ? (
            <>
              {/* Token / QR */}
              {booking.token && (
                <div className="bg-white rounded-2xl border border-slate-100 p-5 flex flex-col items-center gap-3">
                  <div className="w-16 h-16 rounded-2xl bg-indigo-50 flex items-center justify-center">
                    <QrCode size={32} className="text-indigo-400" />
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-slate-400 mb-1">Your booking token</p>
                    <p className="font-mono font-black text-2xl text-indigo-500 tracking-wider">{booking.token}</p>
                    <p className="text-xs text-slate-400 mt-1">Show this at the counter</p>
                  </div>
                </div>
              )}

              {/* Details */}
              <div className="bg-white rounded-2xl border border-slate-100 px-4 py-4 flex flex-col gap-3">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wide">Details</p>
                {businessAddress && <DetailRow icon={<MapPin size={14} className="text-indigo-400" />} label="Location" value={businessAddress} />}
                {!booking.isWalkIn && (
                  <>
                    <DetailRow icon={<Calendar size={14} className="text-indigo-400" />} label="Date" value={booking.date} />
                    <DetailRow icon={<Clock size={14} className="text-indigo-400" />} label="Time" value={booking.time} />
                  </>
                )}
                <DetailRow icon={<Users size={14} className="text-indigo-400" />} label="People" value={`${booking.persons}`} />
                {booking.queuePosition && (
                  <DetailRow icon={<AlertCircle size={14} className="text-amber-400" />} label="Queue #" value={`Position ${booking.queuePosition}`} />
                )}
              </div>

              {/* Payment */}
              {booking.bookingFee != null && (
                <div className="bg-white rounded-2xl border border-slate-100 px-4 py-4 flex flex-col gap-2">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">Payment</p>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Convenience fee</span>
                    <span className="font-semibold">{formatINR(booking.bookingFee / 100)}</span>
                  </div>
                  <div className="flex justify-between text-sm border-t border-slate-50 pt-2 mt-1">
                    <span className="font-bold">Total paid</span>
                    <span className="font-bold text-indigo-500">{formatINR(booking.bookingFee / 100)}</span>
                  </div>
                </div>
              )}

              {/* Cancel confirm */}
              {showCancelConfirm && (
                <div className="bg-red-50 border border-red-100 rounded-2xl px-4 py-4 flex flex-col gap-3">
                  <p className="text-sm text-red-700 font-medium">Cancel your booking? This cannot be undone.</p>
                  <div className="flex gap-2">
                    <button onClick={() => setShowCancelConfirm(false)} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600">Keep it</button>
                    <button onClick={handleCancel} disabled={cancelBooking.isPending} className="flex-1 py-2.5 rounded-xl bg-red-500 text-white text-sm font-semibold disabled:opacity-60">
                      {cancelBooking.isPending ? "Cancelling…" : "Yes, cancel"}
                    </button>
                  </div>
                </div>
              )}
            </>
          ) : null}
        </div>

        {/* Footer */}
        {booking && booking.status !== "cancelled" && booking.status !== "completed" && (
          <div className="shrink-0 bg-white border-t border-slate-100 px-5 py-4 flex gap-3">
            {cancellable && !showCancelConfirm && (
              <button onClick={() => setShowCancelConfirm(true)} className="flex-1 py-3.5 rounded-2xl border-2 border-red-100 text-red-500 font-bold text-sm">
                Cancel booking
              </button>
            )}
            {booking.status === "in-queue" && onViewQueue && (
              <button onClick={onViewQueue} className="flex-1 py-3.5 rounded-2xl bg-amber-400 text-white font-bold text-sm">
                Track queue →
              </button>
            )}
            <button onClick={onClose} className="flex-1 py-3.5 rounded-2xl bg-indigo-500 text-white font-bold text-sm">Done</button>
          </div>
        )}
      </div>
    </div>
  );
}

function DetailRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-2.5">
      {icon}
      <span className="text-xs text-slate-400 w-16 shrink-0">{label}</span>
      <span className="text-sm font-semibold text-slate-700 flex-1">{value}</span>
    </div>
  );
}
