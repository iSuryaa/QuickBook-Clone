"use client";

import { Calendar, Clock, MapPin, Users, ChevronRight, X, QrCode } from "lucide-react";
import { cn } from "@/lib/utils";
import { canCancelBooking } from "@que/utils";
import type { Booking } from "@que/types";

interface BookingCardProps {
  booking: Booking;
  businessName: string;
  serviceName: string;
  onViewDetails: (id: string) => void;
  onCancel?: (id: string) => void;
  onViewQueue?: (id: string) => void;
}

const STATUS_STYLES: Record<Booking["status"], { label: string; classes: string }> = {
  upcoming: { label: "Upcoming", classes: "bg-indigo-50 text-indigo-600" },
  "in-queue": { label: "In Queue", classes: "bg-amber-50 text-amber-600" },
  completed: { label: "Completed", classes: "bg-emerald-50 text-emerald-600" },
  cancelled: { label: "Cancelled", classes: "bg-slate-100 text-slate-400" },
};

export function BookingCard({
  booking,
  businessName,
  serviceName,
  onViewDetails,
  onCancel,
  onViewQueue,
}: BookingCardProps) {
  const { label, classes } = STATUS_STYLES[booking.status];
  const cancellable = canCancelBooking(booking) && booking.status === "upcoming";

  return (
    <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-4 pb-3">
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm truncate">{businessName}</p>
          <p className="text-xs text-slate-500 truncate mt-0.5">{serviceName}</p>
        </div>
        <span className={cn("text-xs font-semibold px-2.5 py-1 rounded-full ml-2 shrink-0", classes)}>
          {label}
        </span>
      </div>

      {/* Details */}
      <div className="px-4 pb-3 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-slate-500">
        {!booking.isWalkIn && (
          <>
            <span className="flex items-center gap-1">
              <Calendar size={11} /> {booking.date}
            </span>
            <span className="flex items-center gap-1">
              <Clock size={11} /> {booking.time}
            </span>
          </>
        )}
        {booking.isWalkIn && booking.queuePosition && (
          <span className="flex items-center gap-1 text-amber-600 font-medium">
            <Users size={11} /> Queue #{booking.queuePosition}
          </span>
        )}
        {booking.persons > 1 && (
          <span className="flex items-center gap-1">
            <Users size={11} /> {booking.persons} people
          </span>
        )}
        {booking.token && (
          <span className="flex items-center gap-1 font-mono text-slate-400">
            <QrCode size={11} /> {booking.token}
          </span>
        )}
      </div>

      {/* Actions */}
      {booking.status !== "cancelled" && booking.status !== "completed" && (
        <div className="flex border-t border-slate-100">
          <button
            onClick={() => onViewDetails(booking.id)}
            className="flex-1 flex items-center justify-center gap-1.5 py-3 text-xs font-semibold text-indigo-500"
          >
            Details <ChevronRight size={13} />
          </button>

          {booking.status === "in-queue" && onViewQueue && (
            <button
              onClick={() => onViewQueue(booking.id)}
              className="flex-1 flex items-center justify-center gap-1.5 py-3 text-xs font-semibold text-amber-600 border-l border-slate-100"
            >
              Track queue
            </button>
          )}

          {cancellable && onCancel && (
            <button
              onClick={() => onCancel(booking.id)}
              className="flex-1 flex items-center justify-center gap-1.5 py-3 text-xs font-semibold text-red-500 border-l border-slate-100"
            >
              <X size={13} /> Cancel
            </button>
          )}
        </div>
      )}
    </div>
  );
}
