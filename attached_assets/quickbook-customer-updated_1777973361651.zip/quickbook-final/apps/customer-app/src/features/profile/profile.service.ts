import { apiClient } from "@/lib/api-client";
import type { Address, SavedCard, Notification } from "@que/types";

interface UpdateProfileData {
  name?: string;
  email?: string;
}

export const profileService = {
  updateProfile: (data: UpdateProfileData, token: string) =>
    apiClient.patch("/users/me", data, token),

  // Addresses
  getAddresses: (token: string) =>
    apiClient.get<Address[]>("/users/me/addresses", token),

  addAddress: (data: Omit<Address, "id">, token: string) =>
    apiClient.post<Address>("/users/me/addresses", data, token),

  updateAddress: (id: string, data: Partial<Address>, token: string) =>
    apiClient.patch<Address>(`/users/me/addresses/${id}`, data, token),

  deleteAddress: (id: string, token: string) =>
    apiClient.delete(`/users/me/addresses/${id}`, token),

  // Cards
  getCards: (token: string) =>
    apiClient.get<SavedCard[]>("/users/me/cards", token),

  addCard: (data: Omit<SavedCard, "id">, token: string) =>
    apiClient.post<SavedCard>("/users/me/cards", data, token),

  deleteCard: (id: string, token: string) =>
    apiClient.delete(`/users/me/cards/${id}`, token),

  // Favorites
  getFavorites: (token: string) =>
    apiClient.get("/users/me/favorites", token),

  toggleFavorite: (businessId: string, token: string) =>
    apiClient.post<{ added: boolean }>(`/users/me/favorites/${businessId}`, {}, token),

  // Notifications
  getNotifications: (token: string) =>
    apiClient.get<Notification[]>("/users/me/notifications", token),

  markRead: (id: string, token: string) =>
    apiClient.patch(`/users/me/notifications/${id}/read`, {}, token),

  markAllRead: (token: string) =>
    apiClient.post("/users/me/notifications/read-all", {}, token),

  deleteNotification: (id: string, token: string) =>
    apiClient.delete(`/users/me/notifications/${id}`, token),
};
