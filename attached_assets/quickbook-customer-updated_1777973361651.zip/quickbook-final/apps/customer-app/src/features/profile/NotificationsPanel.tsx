"use client";

import { X, Bell, CheckCheck, Calendar, Clock, Gift, Star, AlertCircle, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useNotifications, useMarkAllNotificationsRead, useDeleteNotification } from "@/features/profile/use-profile";
import { Skeleton } from "@/components/ui/Skeleton";
import type { Notification } from "@que/types";

interface NotificationsPanelProps {
  onClose: () => void;
}

function getNotifIcon(title: string) {
  const t = title.toLowerCase();
  if (t.includes("book") || t.includes("appointment")) return Calendar;
  if (t.includes("queue") || t.includes("turn") || t.includes("wait")) return Clock;
  if (t.includes("offer") || t.includes("discount") || t.includes("free")) return Gift;
  if (t.includes("review") || t.includes("rate")) return Star;
  return Bell;
}

function getNotifAccent(title: string): string {
  const t = title.toLowerCase();
  if (t.includes("cancel")) return "text-red-500 bg-red-50";
  if (t.includes("confirm") || t.includes("success")) return "text-emerald-600 bg-emerald-50";
  if (t.includes("queue") || t.includes("turn")) return "text-amber-600 bg-amber-50";
  if (t.includes("offer") || t.includes("discount")) return "text-purple-600 bg-purple-50";
  return "text-indigo-500 bg-indigo-50";
}

export function NotificationsPanel({ onClose }: NotificationsPanelProps) {
  const { data: notifications, isLoading } = useNotifications();
  const markAll = useMarkAllNotificationsRead();
  const deleteNotif = useDeleteNotification();

  const unread = (notifications ?? []).filter((n) => !n.read);
  const allRead = unread.length === 0;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50">
      <div
        className="bg-slate-50 w-full max-w-[480px] rounded-t-3xl max-h-[85vh] flex flex-col animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center gap-3 px-5 pt-5 pb-4 bg-white rounded-t-3xl border-b border-slate-100 shrink-0">
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center"
          >
            <X size={18} />
          </button>
          <div className="flex-1">
            <h2 className="font-bold text-base">Notifications</h2>
            {!allRead && (
              <p className="text-xs text-slate-400">{unread.length} unread</p>
            )}
          </div>
          {!allRead && (
            <button
              onClick={() => markAll.mutate()}
              disabled={markAll.isPending}
              className="flex items-center gap-1.5 text-xs font-semibold text-indigo-500 disabled:opacity-50"
            >
              <CheckCheck size={14} />
              Mark all read
            </button>
          )}
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto">
          {isLoading ? (
            <div className="px-5 py-4 flex flex-col gap-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-20 rounded-2xl" />
              ))}
            </div>
          ) : !notifications?.length ? (
            <div className="flex flex-col items-center justify-center py-16 text-center px-8">
              <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center mb-3">
                <Bell size={24} className="text-slate-300" />
              </div>
              <p className="font-semibold text-slate-500 mb-1">All caught up!</p>
              <p className="text-xs text-slate-400">No notifications right now.</p>
            </div>
          ) : (
            <div className="px-5 py-4 flex flex-col gap-2.5 pb-8">
              {(notifications as Notification[]).map((notif) => {
                const Icon = getNotifIcon(notif.title);
                const accent = getNotifAccent(notif.title);
                return (
                  <div
                    key={notif.id}
                    className={cn(
                      "relative bg-white rounded-2xl border overflow-hidden transition-all",
                      notif.read ? "border-slate-100" : "border-indigo-100 shadow-sm shadow-indigo-50",
                    )}
                  >
                    {!notif.read && (
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-indigo-500 rounded-l-2xl" />
                    )}
                    <div className="flex items-start gap-3 px-4 py-3.5 pl-5">
                      <div className={cn("w-9 h-9 rounded-xl flex items-center justify-center shrink-0", accent)}>
                        <Icon size={16} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={cn(
                          "text-sm leading-tight",
                          notif.read ? "font-medium text-slate-600" : "font-bold text-slate-800",
                        )}>
                          {notif.title}
                        </p>
                        <p className="text-xs text-slate-400 mt-0.5 leading-relaxed line-clamp-2">
                          {notif.body}
                        </p>
                        <p className="text-[10px] text-slate-300 mt-1.5 font-medium">{notif.time}</p>
                      </div>
                      <button
                        onClick={() => deleteNotif.mutate(notif.id)}
                        className="shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-slate-300 hover:text-red-400 hover:bg-red-50 transition-colors mt-0.5"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
