"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { profileService } from "./profile.service";
import { useAuth } from "@/features/auth/use-auth";
import type { Address } from "@que/types";

export const profileKeys = {
  addresses:     ["profile", "addresses"]     as const,
  cards:         ["profile", "cards"]         as const,
  favorites:     ["profile", "favorites"]     as const,
  notifications: ["profile", "notifications"] as const,
  profile:       ["profile", "me"]            as const,
};

export function useAddresses() {
  const { token } = useAuth();
  return useQuery({
    queryKey: profileKeys.addresses,
    queryFn: () => profileService.getAddresses(token!),
    enabled: Boolean(token),
  });
}

export function useCards() {
  const { token } = useAuth();
  return useQuery({
    queryKey: profileKeys.cards,
    queryFn: () => profileService.getCards(token!),
    enabled: Boolean(token),
  });
}

export function useFavorites() {
  const { token } = useAuth();
  return useQuery({
    queryKey: profileKeys.favorites,
    queryFn: () => profileService.getFavorites(token!),
    enabled: Boolean(token),
    staleTime: 1000 * 60,
  });
}

export function useNotifications() {
  const { token } = useAuth();
  return useQuery({
    queryKey: profileKeys.notifications,
    queryFn: () => profileService.getNotifications(token!),
    enabled: Boolean(token),
    refetchInterval: 60_000, // poll every 60 s
  });
}

export function useToggleFavorite() {
  const { token } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (businessId: string) => profileService.toggleFavorite(businessId, token!),
    onSuccess: () => qc.invalidateQueries({ queryKey: profileKeys.favorites }),
  });
}

export function useUpdateProfile() {
  const { token } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { name?: string; email?: string }) =>
      profileService.updateProfile(data, token!),
    onSuccess: () => {
      // invalidate profile cache so AuthProvider re-hydrates name
      qc.invalidateQueries({ queryKey: profileKeys.profile });
    },
  });
}

export function useAddAddress() {
  const { token } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<Address, "id">) => profileService.addAddress(data, token!),
    onSuccess: () => qc.invalidateQueries({ queryKey: profileKeys.addresses }),
  });
}

export function useDeleteAddress() {
  const { token } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => profileService.deleteAddress(id, token!),
    onSuccess: () => qc.invalidateQueries({ queryKey: profileKeys.addresses }),
  });
}

export function useMarkAllNotificationsRead() {
  const { token } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => profileService.markAllRead(token!),
    onSuccess: () => qc.invalidateQueries({ queryKey: profileKeys.notifications }),
  });
}

export function useDeleteNotification() {
  const { token } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => profileService.deleteNotification(id, token!),
    onSuccess: () => qc.invalidateQueries({ queryKey: profileKeys.notifications }),
  });
}
