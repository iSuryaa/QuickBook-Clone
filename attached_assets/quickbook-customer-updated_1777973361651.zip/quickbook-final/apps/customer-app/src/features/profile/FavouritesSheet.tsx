"use client";

import { X, Heart, Star, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";
import { useFavorites, useToggleFavorite } from "./use-profile";
import { Skeleton } from "@/components/ui/Skeleton";
import type { Business } from "@que/types";

interface FavouritesSheetProps {
  onClose: () => void;
  onViewBusiness: (id: string) => void;
}

export function FavouritesSheet({ onClose, onViewBusiness }: FavouritesSheetProps) {
  const { data: favData, isLoading } = useFavorites();
  const toggleFav = useToggleFavorite();

  const favourites = (favData as { business: Business }[] | undefined) ?? [];

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50">
      <div className="bg-slate-50 w-full max-w-[480px] rounded-t-3xl max-h-[85vh] flex flex-col animate-slide-up" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3 px-5 pt-5 pb-4 bg-white rounded-t-3xl border-b border-slate-100 shrink-0">
          <button onClick={onClose} className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center"><X size={18} /></button>
          <h2 className="font-bold text-base flex-1">Favourites</h2>
          {favourites.length > 0 && <span className="text-xs text-slate-400">{favourites.length} saved</span>}
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-3 pb-8">
          {isLoading
            ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-2xl" />)
            : favourites.length === 0
              ? (
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <div className="w-14 h-14 rounded-2xl bg-red-50 flex items-center justify-center mb-3">
                    <Heart size={24} className="text-red-300" />
                  </div>
                  <p className="font-semibold text-slate-500 mb-1">No favourites yet</p>
                  <p className="text-xs text-slate-400">Tap the heart icon on any business to save it here.</p>
                </div>
              )
              : favourites.map(({ business }) => (
                <div key={business.id} className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
                  <button onClick={() => { onClose(); onViewBusiness(business.id); }} className="flex items-center gap-3 w-full p-3 text-left">
                    <img src={business.imageUrl} alt={business.name} className="w-16 h-16 rounded-xl object-cover shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{business.name}</p>
                      <p className="text-xs text-slate-400 truncate mt-0.5">{business.address}</p>
                      <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
                        <span className="flex items-center gap-0.5">
                          <Star size={10} className="text-amber-400 fill-amber-400" />
                          {business.rating.toFixed(1)}
                        </span>
                        <span className="flex items-center gap-0.5">
                          <MapPin size={10} />
                          {business.distanceKm} km
                        </span>
                        <span className={cn("font-medium", business.openNow ? "text-emerald-500" : "text-slate-400")}>
                          {business.openNow ? "Open" : "Closed"}
                        </span>
                      </div>
                    </div>
                  </button>
                  <div className="border-t border-slate-50 flex">
                    <button
                      onClick={() => onViewBusiness(business.id)}
                      className="flex-1 py-3 text-xs font-semibold text-indigo-500"
                    >
                      View & Book
                    </button>
                    <button
                      onClick={() => toggleFav.mutate(business.id)}
                      className="flex-1 py-3 text-xs font-semibold text-red-400 border-l border-slate-50 flex items-center justify-center gap-1"
                    >
                      <Heart size={12} className="fill-red-400" /> Remove
                    </button>
                  </div>
                </div>
              ))
          }
        </div>
      </div>
    </div>
  );
}
