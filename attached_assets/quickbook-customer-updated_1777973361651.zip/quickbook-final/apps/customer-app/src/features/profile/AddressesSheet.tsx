"use client";

import { useState } from "react";
import { X, Plus, Home, Briefcase, MapPin, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAddresses, useAddAddress, useDeleteAddress } from "./use-profile";
import { useToast } from "@/components/ui/Toast";
import { Skeleton } from "@/components/ui/Skeleton";
import type { AddressLabel } from "@que/types";

interface AddressesSheetProps {
  onClose: () => void;
}

const LABEL_ICONS: Record<AddressLabel, React.ReactNode> = {
  home: <Home size={15} />,
  work: <Briefcase size={15} />,
  other: <MapPin size={15} />,
};

export function AddressesSheet({ onClose }: AddressesSheetProps) {
  const { data: addresses, isLoading } = useAddresses();
  const addAddress = useAddAddress();
  const deleteAddress = useDeleteAddress();
  const { toast } = useToast();
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ label: "home" as AddressLabel, line1: "", line2: "", city: "", pincode: "" });

  const handleAdd = () => {
    if (!form.line1.trim() || !form.city.trim() || !form.pincode.trim()) {
      toast("Please fill all required fields", "error"); return;
    }
    addAddress.mutate(form, {
      onSuccess: () => { toast("Address saved", "success"); setShowAdd(false); setForm({ label: "home", line1: "", line2: "", city: "", pincode: "" }); },
      onError: (e) => toast(e.message, "error"),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50">
      <div className="bg-slate-50 w-full max-w-[480px] rounded-t-3xl max-h-[85vh] flex flex-col animate-slide-up" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3 px-5 pt-5 pb-4 bg-white rounded-t-3xl border-b border-slate-100 shrink-0">
          <button onClick={onClose} className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center"><X size={18} /></button>
          <h2 className="font-bold text-base flex-1">Saved addresses</h2>
          <button onClick={() => setShowAdd(true)} className="flex items-center gap-1.5 text-xs font-bold text-indigo-500"><Plus size={14} /> Add</button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-3 pb-8">
          {isLoading ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-2xl" />) :
            !addresses?.length && !showAdd ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <MapPin size={28} className="text-slate-300 mb-3" />
                <p className="font-semibold text-slate-500 mb-1">No saved addresses</p>
                <button onClick={() => setShowAdd(true)} className="mt-2 bg-indigo-500 text-white text-sm font-bold px-5 py-2.5 rounded-full">Add address</button>
              </div>
            ) : (
              (addresses ?? []).map((addr) => (
                <div key={addr.id} className="bg-white rounded-2xl border border-slate-100 px-4 py-3.5 flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-400 shrink-0">{LABEL_ICONS[addr.label]}</div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm capitalize">{addr.label}</p>
                    <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">{addr.line1}{addr.line2 ? `, ${addr.line2}` : ""}</p>
                    <p className="text-xs text-slate-400">{addr.city} — {addr.pincode}</p>
                  </div>
                  <button onClick={() => deleteAddress.mutate(addr.id, { onSuccess: () => toast("Address removed", "info") })} className="w-8 h-8 flex items-center justify-center text-slate-300 hover:text-red-400 transition-colors"><Trash2 size={15} /></button>
                </div>
              ))
            )
          }

          {showAdd && (
            <div className="bg-white rounded-2xl border border-indigo-100 p-4 flex flex-col gap-3">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wide">New address</p>
              {/* Label picker */}
              <div className="flex gap-2">
                {(["home", "work", "other"] as AddressLabel[]).map((l) => (
                  <button key={l} onClick={() => setForm((f) => ({ ...f, label: l }))}
                    className={cn("flex-1 py-2 rounded-xl border text-xs font-bold capitalize transition-all", form.label === l ? "bg-indigo-500 text-white border-indigo-500" : "border-slate-200 text-slate-500")}>
                    {l}
                  </button>
                ))}
              </div>
              {[
                { key: "line1", placeholder: "Address line 1 *" },
                { key: "line2", placeholder: "Address line 2" },
                { key: "city", placeholder: "City *" },
                { key: "pincode", placeholder: "Pincode *" },
              ].map(({ key, placeholder }) => (
                <input key={key} value={(form as Record<string, string>)[key]} onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                  placeholder={placeholder}
                  className="w-full border border-slate-100 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-indigo-300 bg-slate-50" />
              ))}
              <div className="flex gap-2 mt-1">
                <button onClick={() => setShowAdd(false)} className="flex-1 py-3 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600">Cancel</button>
                <button onClick={handleAdd} disabled={addAddress.isPending} className="flex-1 py-3 rounded-xl bg-indigo-500 text-white text-sm font-bold disabled:opacity-50">
                  {addAddress.isPending ? "Saving…" : "Save address"}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
