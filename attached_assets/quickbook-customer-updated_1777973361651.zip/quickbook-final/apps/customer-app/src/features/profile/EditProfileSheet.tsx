"use client";

import { useState } from "react";
import { X, User, Mail, Phone } from "lucide-react";
import { useUpdateProfile } from "./use-profile";
import { useAuth } from "@/features/auth/use-auth";
import { useToast } from "@/components/ui/Toast";

interface EditProfileSheetProps {
  onClose: () => void;
}

export function EditProfileSheet({ onClose }: EditProfileSheetProps) {
  const { user } = useAuth();
  const updateProfile = useUpdateProfile();
  const { toast } = useToast();

  const [name, setName] = useState(user?.name ?? "");
  const [email, setEmail] = useState(user?.email ?? "");

  const handleSave = () => {
    if (!name.trim() || name.trim().length < 2) {
      toast("Name must be at least 2 characters", "error");
      return;
    }
    updateProfile.mutate(
      { name: name.trim(), email: email.trim() || undefined },
      {
        onSuccess: () => {
          toast("Profile updated!", "success");
          onClose();
        },
        onError: (err) => toast(err.message, "error"),
      },
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50">
      <div
        className="bg-white w-full max-w-[480px] rounded-t-3xl animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center gap-3 px-5 pt-5 pb-4 border-b border-slate-100">
          <button onClick={onClose} className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center">
            <X size={18} />
          </button>
          <h2 className="font-bold text-base flex-1">Edit profile</h2>
          <button
            onClick={handleSave}
            disabled={updateProfile.isPending}
            className="bg-indigo-500 text-white text-sm font-bold px-4 py-2 rounded-full disabled:opacity-50"
          >
            {updateProfile.isPending ? "Saving…" : "Save"}
          </button>
        </div>

        <div className="px-5 py-6 flex flex-col gap-4">
          {/* Avatar */}
          <div className="flex justify-center mb-2">
            <div className="w-20 h-20 rounded-2xl bg-indigo-100 flex items-center justify-center">
              <span className="text-3xl font-bold text-indigo-500">
                {(name || user?.name || "?").charAt(0).toUpperCase()}
              </span>
            </div>
          </div>

          <FieldInput
            icon={<User size={16} className="text-slate-400" />}
            label="Full name"
            value={name}
            onChange={setName}
            placeholder="Your full name"
          />

          <FieldInput
            icon={<Phone size={16} className="text-slate-400" />}
            label="Phone"
            value={user?.phone ?? ""}
            onChange={() => {}}
            placeholder="Phone number"
            disabled
          />

          <FieldInput
            icon={<Mail size={16} className="text-slate-400" />}
            label="Email (optional)"
            value={email}
            onChange={setEmail}
            placeholder="your@email.com"
            type="email"
          />
        </div>
        <div className="h-8" />
      </div>
    </div>
  );
}

function FieldInput({
  icon, label, value, onChange, placeholder, type = "text", disabled = false,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  disabled?: boolean;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <p className="text-xs font-bold text-slate-400 uppercase tracking-wide px-1">{label}</p>
      <div className={`flex items-center gap-3 bg-slate-50 rounded-2xl px-4 py-3.5 border ${disabled ? "opacity-50" : "border-slate-100"}`}>
        {icon}
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate-300"
        />
      </div>
    </div>
  );
}
