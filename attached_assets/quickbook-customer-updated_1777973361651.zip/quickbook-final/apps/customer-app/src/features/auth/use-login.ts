"use client";

import { useState, useCallback, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { authService } from "./auth.service";
import { useAuth } from "./use-auth";
import type { AuthUser } from "@/lib/auth-store";

export type LoginStep = "phone" | "otp" | "profile";

const phoneSchema = z.object({
  phone: z
    .string()
    .regex(/^\d{10}$/, "Enter a valid 10-digit mobile number"),
});

const otpSchema = z.object({
  otp: z.string().length(6, "Enter the 6-digit code"),
});

const profileSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
});

export function useLogin(onSuccess?: () => void) {
  const { login } = useAuth();
  const [step, setStep] = useState<LoginStep>("phone");
  const [verifiedPhone, setVerifiedPhone] = useState("");
  const [resendCountdown, setResendCountdown] = useState(0);

  // Countdown timer for OTP resend
  useEffect(() => {
    if (resendCountdown <= 0) return;
    const t = setTimeout(() => setResendCountdown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [resendCountdown]);

  const phoneForm = useForm({ resolver: zodResolver(phoneSchema) });
  const otpForm = useForm({ resolver: zodResolver(otpSchema) });
  const profileForm = useForm({ resolver: zodResolver(profileSchema) });

  const sendOtpMutation = useMutation({
    mutationFn: (phone: string) => authService.sendOtp({ phone }),
    onSuccess: (_, phone) => {
      setVerifiedPhone(phone);
      setResendCountdown(30);
      setStep("otp");
    },
  });

  const verifyOtpMutation = useMutation({
    mutationFn: ({ phone, otp }: { phone: string; otp: string }) =>
      authService.verifyOtp({ phone, otp }),
    onSuccess: async (data) => {
      if (data.isNewUser) {
        setStep("profile");
      } else {
        // Existing user — fetch profile and complete login
        const user = await authService.getMe(data.token);
        login(data.token, user as AuthUser);
        onSuccess?.();
      }
    },
  });

  const signupMutation = useMutation({
    mutationFn: ({ name, email }: { name: string; email?: string }) =>
      authService.signup({ phone: verifiedPhone, name, email: email || undefined }),
    onSuccess: (data) => {
      login(data.token, data.user as AuthUser);
      onSuccess?.();
    },
  });

  const handleSendOtp = phoneForm.handleSubmit((values) => {
    sendOtpMutation.mutate(values.phone);
  });

  const handleVerifyOtp = otpForm.handleSubmit((values) => {
    verifyOtpMutation.mutate({ phone: verifiedPhone, otp: values.otp });
  });

  const handleSignup = profileForm.handleSubmit((values) => {
    signupMutation.mutate({ name: values.name, email: values.email || undefined });
  });

  const handleResend = useCallback(() => {
    if (resendCountdown > 0) return;
    sendOtpMutation.mutate(verifiedPhone);
  }, [verifiedPhone, resendCountdown, sendOtpMutation]);

  return {
    step,
    verifiedPhone,
    resendCountdown,
    phoneForm,
    otpForm,
    profileForm,
    handleSendOtp,
    handleVerifyOtp,
    handleSignup,
    handleResend,
    isSendingOtp: sendOtpMutation.isPending,
    isVerifying: verifyOtpMutation.isPending,
    isSigningUp: signupMutation.isPending,
    sendOtpError: sendOtpMutation.error?.message,
    verifyError: verifyOtpMutation.error?.message,
    signupError: signupMutation.error?.message,
  };
}
