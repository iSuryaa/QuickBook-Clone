"use client";

import { useLogin } from "./use-login";
import { X, Phone, Lock, User, Mail } from "lucide-react";
import { cn } from "@/lib/utils";
import React from "react";

interface LoginScreenProps {
  onBack: () => void;
  onSuccess: () => void;
}

export function LoginScreen({ onBack, onSuccess }: LoginScreenProps) {
  const login = useLogin(onSuccess);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50">
      <div
        className="bg-white w-full max-w-[480px] rounded-t-3xl max-h-[90vh] overflow-y-auto animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Handle + header */}
        <div className="flex items-center gap-3 px-5 pt-5 pb-4 border-b border-slate-100">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center"
          >
            <X size={18} />
          </button>
          <h1 className="text-base font-bold flex-1">Sign in</h1>
        </div>

        <div className="px-5 py-6 flex flex-col gap-6">
          {login.step === "phone" && (
            <PhoneStep
              form={login.phoneForm}
              onSubmit={login.handleSendOtp}
              isLoading={login.isSendingOtp}
              error={login.sendOtpError}
            />
          )}
          {login.step === "otp" && (
            <OtpStep
              phone={login.verifiedPhone}
              form={login.otpForm}
              onSubmit={login.handleVerifyOtp}
              onResend={login.handleResend}
              countdown={login.resendCountdown}
              isLoading={login.isVerifying}
              error={login.verifyError}
            />
          )}
          {login.step === "profile" && (
            <ProfileStep
              form={login.profileForm}
              onSubmit={login.handleSignup}
              isLoading={login.isSigningUp}
              error={login.signupError}
            />
          )}
        </div>
        <div className="h-8" />
      </div>
    </div>
  );
}

function PhoneStep({ form, onSubmit, isLoading, error }: {
  form: ReturnType<typeof useLogin>["phoneForm"];
  onSubmit: () => void; isLoading: boolean; error?: string;
}) {
  return (
    <div className="flex flex-col gap-5">
      <div>
        <h2 className="text-2xl font-bold mb-1">Welcome back 👋</h2>
        <p className="text-slate-500 text-sm">Enter your mobile number to continue</p>
      </div>
      <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 flex items-center gap-3">
        <div className="text-slate-500 font-semibold text-sm">+91</div>
        <div className="w-px h-5 bg-slate-200" />
        <Phone size={16} className="text-slate-400" />
        <input
          type="tel" inputMode="numeric" maxLength={10}
          placeholder="10-digit mobile number"
          className="flex-1 outline-none text-sm bg-transparent"
          {...form.register("phone")}
        />
      </div>
      {form.formState.errors.phone && (
        <p className="text-red-500 text-xs">{form.formState.errors.phone.message}</p>
      )}
      {error && <p className="text-red-500 text-xs">{error}</p>}
      <button
        onClick={onSubmit} disabled={isLoading}
        className="bg-indigo-500 text-white rounded-2xl py-4 font-semibold text-sm disabled:opacity-60"
      >
        {isLoading ? "Sending OTP…" : "Get OTP"}
      </button>
    </div>
  );
}

function OtpStep({ phone, form, onSubmit, onResend, countdown, isLoading, error }: {
  phone: string; form: ReturnType<typeof useLogin>["otpForm"];
  onSubmit: () => void; onResend: () => void; countdown: number;
  isLoading: boolean; error?: string;
}) {
  return (
    <div className="flex flex-col gap-5">
      <div>
        <h2 className="text-2xl font-bold mb-1">Enter OTP</h2>
        <p className="text-slate-500 text-sm">
          Sent to <span className="font-semibold text-slate-700">+91 {phone}</span>
        </p>
      </div>
      <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 flex items-center gap-3">
        <Lock size={16} className="text-slate-400" />
        <input
          type="tel" inputMode="numeric" maxLength={6} placeholder="6-digit code"
          className="flex-1 outline-none text-sm bg-transparent tracking-widest font-mono"
          {...form.register("otp")}
        />
      </div>
      {form.formState.errors.otp && (
        <p className="text-red-500 text-xs">{form.formState.errors.otp.message}</p>
      )}
      {error && <p className="text-red-500 text-xs">{error}</p>}
      <button onClick={onSubmit} disabled={isLoading}
        className="bg-indigo-500 text-white rounded-2xl py-4 font-semibold text-sm disabled:opacity-60">
        {isLoading ? "Verifying…" : "Verify OTP"}
      </button>
      <button onClick={onResend} disabled={countdown > 0}
        className={cn("text-sm text-center", countdown > 0 ? "text-slate-400" : "text-indigo-500 font-medium")}>
        {countdown > 0 ? `Resend in ${countdown}s` : "Resend OTP"}
      </button>
    </div>
  );
}

function ProfileStep({ form, onSubmit, isLoading, error }: {
  form: ReturnType<typeof useLogin>["profileForm"];
  onSubmit: () => void; isLoading: boolean; error?: string;
}) {
  return (
    <div className="flex flex-col gap-5">
      <div>
        <h2 className="text-2xl font-bold mb-1">Complete your profile</h2>
        <p className="text-slate-500 text-sm">Just a few details to get started</p>
      </div>
      <FieldInput icon={<User size={16} className="text-slate-400" />} placeholder="Full name"
        {...form.register("name")} error={form.formState.errors.name?.message} />
      <FieldInput icon={<Mail size={16} className="text-slate-400" />} placeholder="Email (optional)"
        type="email" {...form.register("email")} error={form.formState.errors.email?.message} />
      {error && <p className="text-red-500 text-xs">{error}</p>}
      <button onClick={onSubmit} disabled={isLoading}
        className="bg-indigo-500 text-white rounded-2xl py-4 font-semibold text-sm disabled:opacity-60">
        {isLoading ? "Creating account…" : "Get started"}
      </button>
    </div>
  );
}

const FieldInput = React.forwardRef<
  HTMLInputElement,
  React.InputHTMLAttributes<HTMLInputElement> & { icon: React.ReactNode; error?: string }
>(({ icon, error, ...props }, ref) => (
  <div className="flex flex-col gap-1">
    <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 flex items-center gap-3">
      {icon}
      <input ref={ref} className="flex-1 outline-none text-sm bg-transparent" {...props} />
    </div>
    {error && <p className="text-red-500 text-xs px-1">{error}</p>}
  </div>
));
FieldInput.displayName = "FieldInput";
