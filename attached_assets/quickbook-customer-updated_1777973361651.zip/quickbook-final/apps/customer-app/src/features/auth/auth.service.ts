import { apiClient } from "@/lib/api-client";
import type { SendOtpInput, VerifyOtpInput, SignupInput, LoginResponse } from "@que/shared";

export const authService = {
  sendOtp: (data: SendOtpInput) =>
    apiClient.post<{ message: string }>("/auth/otp/send", data),

  verifyOtp: (data: VerifyOtpInput) =>
    apiClient.post<{ token: string; isNewUser: boolean }>("/auth/otp/verify", data),

  signup: (data: SignupInput) =>
    apiClient.post<LoginResponse>("/auth/signup", data),

  getMe: (token: string) =>
    apiClient.get<LoginResponse["user"]>("/auth/me", token),
};
