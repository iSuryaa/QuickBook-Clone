"use client";

import { useState, useCallback, useEffect, type ReactNode } from "react";
import { AuthContext, type AuthContextValue } from "./use-auth";
import { authStore, type AuthUser } from "@/lib/auth-store";
import { queryClient } from "@/lib/query-client";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);

  // Hydrate from localStorage on mount (client-only)
  useEffect(() => {
    setToken(authStore.getToken());
    setUser(authStore.getUser());
  }, []);

  const login = useCallback((newToken: string, newUser: AuthUser) => {
    authStore.set(newToken, newUser);
    setToken(newToken);
    setUser(newUser);
  }, []);

  const logout = useCallback(() => {
    authStore.clear();
    setToken(null);
    setUser(null);
    queryClient.clear();
  }, []);

  const value: AuthContextValue = {
    user,
    token,
    isLoggedIn: Boolean(token),
    login,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
