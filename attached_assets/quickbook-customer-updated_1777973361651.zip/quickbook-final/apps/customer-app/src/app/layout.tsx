import type { Metadata } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { Providers } from "./providers";

const jakartaSans = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-jakarta",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Que — Appointment Booking",
  description: "Book appointments, skip queues, manage your schedule.",
  themeColor: "#6366f1",
  manifest: "/manifest.json",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={jakartaSans.variable}>
      <body className="bg-slate-50 font-jakarta antialiased">
        <div className="max-w-[480px] mx-auto min-h-screen relative">
          <Providers>{children}</Providers>
        </div>
      </body>
    </html>
  );
}
