import { AppShell } from "@/features/shared/AppShell";

export default function Page() {
  return <AppShell />;
}
