# Que Booking — Monorepo

A production-ready appointment booking platform. Refactored from a Replit proof-of-concept into a clean, modular monorepo.

---

## Architecture

```
que-booking/
├── apps/
│   ├── customer-app/          # Next.js 15 frontend (mobile-first PWA)
│   └── api/                   # Express + Prisma REST API
│
├── packages/
│   ├── types/                 # Shared TypeScript domain types
│   ├── utils/                 # Shared utility functions
│   └── shared/                # Shared Zod validation schemas
│
├── .env.example               # Environment variable template
├── pnpm-workspace.yaml
└── tsconfig.base.json
```

### API module structure

```
apps/api/src/modules/
├── auth/          auth.repository  →  auth.service  →  auth.controller  →  auth.routes
├── users/         users.repository →  users.service →  users.controller →  users.routes
├── businesses/    businesses.*
├── bookings/      bookings.*
├── staff/         staff.*
└── payments/      payments.*
```

### Frontend feature structure

```
apps/customer-app/src/
├── app/                    # Next.js App Router (layout, page, providers)
├── components/ui/          # Shared UI: TopBar, BottomNav, Skeleton, Toast, SearchBar
├── features/
│   ├── auth/               # AuthProvider, LoginScreen, use-auth, use-login, auth.service
│   ├── businesses/         # use-businesses, businesses.service, BusinessCard, FilterSheet
│   ├── bookings/           # use-bookings, bookings.service, BookingCard
│   ├── profile/            # use-profile, profile.service
│   └── shared/             # AppShell, tab screens (Home, Explore, Bookings, Profile)
└── lib/                    # api-client, auth-store, query-client, utils
```

---

## Prerequisites

| Tool | Version |
|------|---------|
| Node.js | ≥ 20 |
| pnpm | ≥ 9 |
| PostgreSQL | ≥ 15 |

Install pnpm globally if needed:
```bash
npm install -g pnpm
```

---

## Quick Start (Windows / macOS / Linux)

### 1. Install dependencies

```bash
pnpm install
```

### 2. Configure environment

```bash
# Windows CMD
copy .env.example apps\api\.env

# Windows PowerShell
Copy-Item .env.example apps\api\.env

# macOS / Linux
cp .env.example apps/api/.env
```

Edit `apps/api/.env` and fill in:

```env
DATABASE_URL=postgresql://user:password@localhost:5432/que_booking
JWT_SECRET=<generate with: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))">
```

For the frontend, create `apps/customer-app/.env.local`:

```env
NEXT_PUBLIC_API_URL=http://localhost:3001
```

### 3. Set up the database

```bash
# Generate Prisma client
pnpm db:generate

# Run migrations
pnpm db:migrate

# Seed with sample data (businesses, demo user)
pnpm db:seed
```

### 4. Start development

```bash
# Start API + frontend together
pnpm dev

# Or start individually
pnpm dev:api
pnpm dev:web
```

| Service | URL |
|---------|-----|
| Frontend | http://localhost:3000 |
| API | http://localhost:3001/api |
| Health check | http://localhost:3001/api/healthz |
| Prisma Studio | `pnpm db:studio` |

---

## Scripts (all Windows-compatible)

| Script | Description |
|--------|-------------|
| `pnpm dev` | Start all apps in parallel |
| `pnpm dev:api` | Start API only (tsx watch) |
| `pnpm dev:web` | Start frontend only |
| `pnpm build` | Type-check + build all apps |
| `pnpm typecheck` | Type-check all packages |
| `pnpm db:generate` | Regenerate Prisma client |
| `pnpm db:migrate` | Run database migrations |
| `pnpm db:migrate:prod` | Deploy migrations (production) |
| `pnpm db:studio` | Open Prisma Studio |
| `pnpm db:seed` | Seed sample data |
| `pnpm format` | Format with Prettier |
| `pnpm clean` | Remove all dist / .next outputs |

---

## API Endpoints

### Auth
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/auth/otp/send` | Send OTP to phone number |
| POST | `/api/auth/otp/verify` | Verify OTP, returns token |
| POST | `/api/auth/signup` | Complete profile for new users |
| GET | `/api/auth/me` | Get authenticated user |

### Businesses
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/businesses` | List businesses (filterable) |
| GET | `/api/businesses/:id` | Business detail with services + staff |
| GET | `/api/businesses/:id/reviews` | Paginated reviews |
| POST | `/api/businesses/:id/reviews` | Add a review (auth required) |

### Bookings (all auth required)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/bookings` | List user bookings |
| POST | `/api/bookings` | Create booking |
| GET | `/api/bookings/:id` | Booking detail |
| POST | `/api/bookings/:id/cancel` | Cancel booking |
| GET | `/api/bookings/:id/queue` | Live queue position |

### Users (all auth required)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/users/me` | Profile |
| PATCH | `/api/users/me` | Update profile |
| GET/POST | `/api/users/me/addresses` | Saved addresses |
| PATCH/DELETE | `/api/users/me/addresses/:id` | Edit/delete address |
| GET/POST | `/api/users/me/cards` | Saved payment cards |
| DELETE | `/api/users/me/cards/:id` | Remove card |
| GET | `/api/users/me/favorites` | Favourite businesses |
| POST | `/api/users/me/favorites/:businessId` | Toggle favourite |
| GET | `/api/users/me/notifications` | Notifications |
| POST | `/api/users/me/notifications/read-all` | Mark all read |

### Staff
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/staff/business/:businessId` | Staff for a business |
| GET | `/api/staff/:staffId/slots` | Available time slots |

### Payments (auth required)
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/payments/initiate` | Initiate payment |
| POST | `/api/payments/confirm` | Confirm payment |
| GET | `/api/payments/booking/:bookingId` | Payment status |

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 15, React 19, TypeScript, Tailwind CSS |
| State / data | TanStack Query v5 |
| Forms | React Hook Form + Zod |
| Backend | Express 4, TypeScript, tsx |
| ORM | Prisma 6 |
| Database | PostgreSQL 15+ |
| Validation | Zod (shared schemas across FE + BE) |
| Auth | JWT (jsonwebtoken) + OTP |
| Logging | Pino + pino-http |
| Monorepo | pnpm workspaces |
| Cross-platform | cross-env (no shell scripts) |

---

## Environment Variables Reference

See `.env.example` for all variables with descriptions.

**API (`apps/api/.env`)**
```
DATABASE_URL          PostgreSQL connection string
PORT                  API port (default: 3001)
NODE_ENV              development | production | test
JWT_SECRET            ≥ 32 character secret
JWT_EXPIRES_IN        Token lifetime (default: 7d)
CORS_ORIGINS          Comma-separated allowed origins
```

**Frontend (`apps/customer-app/.env.local`)**
```
NEXT_PUBLIC_API_URL   API base URL (default: http://localhost:3001)
```

---

## Demo Credentials

After running `pnpm db:seed`:

| Field | Value |
|-------|-------|
| Phone | `9876543210` |
| OTP | Check API server console log (dev mode prints OTP) |
